# 7406102
# Create (sane/safe) filename from any (unsafe) string
def sanitize_filename(filename):
    keepcharacters = (' ','.','_')
    return "".join(c for c in filename if c.isalnum() or c in keepcharacters).rstrip()
# Test
print(sanitize_filename("ad\nbla'{-+\)(ç?"))
