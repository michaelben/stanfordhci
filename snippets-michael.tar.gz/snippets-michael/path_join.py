# 3380484
# using backslash in path string on windows(not to escape backslash in str)

import os

def path_join(cmd, ini):
    path= os.getcwd()
    final = os.path.join(path, cmd) + ' ' + \
         os.path.join(path, ini)
    return final

print(path_join('xulrunner.exe', 'application.ini'))
