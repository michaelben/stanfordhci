# 8595973
# truncate to 3 decimals in python
def truncate_3_decimals(d):
    return '%.3f' % d
# Test
print(truncate_3_decimals(1324343032.324325235))
