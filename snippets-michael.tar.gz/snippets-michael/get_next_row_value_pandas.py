# 23151246
# iterrows pandas get next rows value
import pandas as pd
def get_next_row_value_pandas(df):
    last = df.iloc[0]
    for i in range(1, df.shape[0]):
        print(last)
        print(df.iloc[i])
        last = df.iloc[i]
# Test
get_next_row_value_pandas(pd.DataFrame(['AA', 'BB', 'CC'], columns = ['value']))
