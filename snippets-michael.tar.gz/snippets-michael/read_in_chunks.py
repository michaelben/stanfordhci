# 4566498
# Python file iterator over a binary file with newer idiom
def read_in_chunks(infile, chunk_size=1024*64):
    chunk = infile.read(chunk_size)
    while chunk:
        yield chunk
        chunk = infile.read(chunk_size)
# Test
with open('read_in_chunks.py', 'rb') as infile:
    for chunk in read_in_chunks(infile):
        print(chunk)
