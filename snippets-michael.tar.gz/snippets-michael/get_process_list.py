# 1091327
# Get the process list in Python
import psutil
def get_process_list():
    return psutil.pids()
# Test
print(get_process_list())
