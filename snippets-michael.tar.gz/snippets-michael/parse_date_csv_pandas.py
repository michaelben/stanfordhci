# 12269528
# Using python pandas to parse CSV with date in format Year, Day, Hour, Min, Sec
import pandas as pd
from datetime import datetime, timedelta
from io import StringIO
def parse_date_csv_pandas(csv_file):
    def parse(yr, doy, hr, min, sec):
        yr, doy, hr, min = [int(x) for x in [yr, doy, hr, min]]
        sec = float(sec)
        mu_sec = int((sec - int(sec)) * 1e6)
        sec = int(sec)
        dt = datetime(yr - 1, 12, 31)
        delta = timedelta(days=doy, hours=hr, minutes=min, seconds=sec,
                          microseconds=mu_sec)
        return dt + delta
    return pd.read_csv(csv_file, parse_dates={'datetime':      
           ['Year','Day','Hour','Min','Sec.']}, 
           date_parser=parse, index_col='datetime')
# Test
print(parse_date_csv_pandas(StringIO("""\
Year,Day,Hour,Min,Sec.,P1'S1
 2003,  1, 0, 0,12.22, 0.541
 2003,  1, 1, 0,20.69, 0.708
 2003,  1, 2, 0, 4.95, 0.520
 2003,  1, 3, 0,13.42, 0.539
""")))
