# 5910703
# Get all methods of a python class with given decorator
import ast, inspect

def get_all_methods_with_given_decorator(cls, decor):
    def findAllDecorators(target):
        res = {}
        def visit_FunctionDef(node):
            res[node.name] = [ast.dump(e) for e in node.decorator_list]

        V = ast.NodeVisitor()
        V.visit_FunctionDef = visit_FunctionDef
        V.visit(compile(inspect.getsource(target), '?', 'exec', ast.PyCF_ONLY_AST))
        return res

    decorators = findAllDecorators(A)

    methods = []
    for m,d in decorators.items():
        if d and decor in d[0]:
            methods.append(m)

    return methods
# Test
def decorator1(f):
    def new_f():
        print("Entering decorator1", f.__name__)
        f()
    new_f.__name__ = f.__name__
    return new_f

def decorator2(f):
    def new_f():
        print("Entering decorator2", f.__name__)
        f()
    new_f.__name__ = f.__name__
    return new_f

class A():
    def method_a(self):
        pass

    @decorator1
    def method_b(self, b):
        pass

    @decorator2
    def method_c(self, t=5):
        pass

    @decorator2
    def method_d(self, t=5): pass
print(get_all_methods_with_given_decorator(A, 'decorator2'))
