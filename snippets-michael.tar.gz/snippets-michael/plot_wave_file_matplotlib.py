# 18625085
# Plot a wav file
import matplotlib.pyplot as plt
import numpy as np
import wave
import sys

def plot_wave_file_matplotlib(wavefile):
    spf = wave.open(wavefile, 'r')

    #Extract Raw Audio from Wav File
    signal = spf.readframes(-1)
    signal = np.fromstring(signal, 'Int16')

    #If Stereo
    #if spf.getnchannels() == 2:
    #    print('Just mono files')
    #    sys.exit(0)

    plt.figure(1)
    plt.title('Signal Wave...')
    plt.plot(signal)
    plt.show()
# Test
plot_wave_file_matplotlib('test.wav.1')
