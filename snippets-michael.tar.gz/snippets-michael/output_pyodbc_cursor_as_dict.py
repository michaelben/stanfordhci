# 16519385
# Output pyodbc cursor results as python dictionary
def output_pyodbc_cursor_as_dict(conn, sql):
    cursor = conn.cursor().execute(sql)
    columns = [column[0] for column in cursor.description]
    results = []
    for row in cursor.fetchall():
        results.append(dict(zip(columns, row)))

    return results
# Test
