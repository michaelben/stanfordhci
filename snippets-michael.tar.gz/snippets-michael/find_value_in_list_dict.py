# 17149561
# How to find a value in a list of python dictionaries?
import datetime
def find_value_in_list_dict():
    label = [{'date': datetime.datetime(2013, 6, 17, 8, 56, 24, 2347),
              'name': 'Test',
              'pos': 6},
                 {'date': datetime.datetime(2013, 6, 17, 8, 56, 24, 2347),
                  'name': 'Name 2',
              'pos': 1}]
    return any(d['name'] == 'Test' for d in label)
# Test
print(find_value_in_list_dict())
