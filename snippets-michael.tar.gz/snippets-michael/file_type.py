# 3703276
# How to tell if a file is gzip compressed?
import mimetypes

def file_type(filename):
    type = mimetypes.guess_type(filename)
    return type
# Test
print(file_type('logo.png.gz'))
