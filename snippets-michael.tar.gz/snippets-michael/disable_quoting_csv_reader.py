# 494054
# How can I disable quoting in the Python CSV reader?
import csv
from io import StringIO
def disable_quoting_csv_reader():
    class MyDialect(csv.Dialect):
        quotechar = '\x07'
        delimiter = ','
        lineterminator = '\n'
        doublequote = False
        skipinitialspace = False
        quoting = csv.QUOTE_NONE
        escapechar = '\\'
    data = """\
    1,2,3,4,"5
    1,2,3,4,5
    """
    dialect = MyDialect()
    reader = csv.reader(StringIO(data), dialect=dialect)
    for i in reader: print(i)
# Test
disable_quoting_csv_reader()
