# 8217269
# Decrypting strings in Python that were encrypted with MCRYPT_RIJNDAEL_256 in PHP
import rijndael
import base64

def encrypt_rijndael(key, plaintext):
    KEY_SIZE = 16
    BLOCK_SIZE = 32

    padded_key = key.ljust(KEY_SIZE, '\0')
    padded_text = plaintext + (BLOCK_SIZE - len(plaintext) % BLOCK_SIZE) * '\0'

    r = rijndael.rijndael(padded_key, BLOCK_SIZE)

    ciphertext = ''
    for start in range(0, len(padded_text), BLOCK_SIZE):
        ciphertext += r.encrypt(padded_text[start:start+BLOCK_SIZE])

    encoded = base64.b64encode(ciphertext.encode())

    return encoded.decode()
# Test
print(encrypt_rijndael('MyKey', 'test'))
