# 8376335
# Styling part of label in legend in matplotlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc
import shutil
import sys

def styling_label_legend_latex_matplotlib():
    latex = shutil.which('latex')
    if not latex:
        print('latex not found. please install LaTex')
        sys.exit(-1)

    # activate latex text rendering
    rc('text', usetex=True)

    x = np.arange(10)
    y = np.random.random(10)
    z = np.random.random(10)

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(x, y, label = r"This is \textbf{line 1}")
    ax.plot(x, z, label = r"This is \textit{line 2}")
    ax.legend()
    plt.show()
# Test
styling_label_legend_latex_matplotlib()
