# 5347003
# Python: Find value in list smaller than target
def get_next_low_value(temp, templist):
    templist = (int(t) for t in templist if t != '')
    templist = [t for t in templist if t < int(temp)]
    if templist: return max(templist)
    else: return None
# Test
print(get_next_low_value(55, [10, 20, 50, 200, 100, 300, 250, 150]))
