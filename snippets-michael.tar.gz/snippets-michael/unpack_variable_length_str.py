# 3753589
# packing and unpacking variable length array/string using the struct module in python

import struct
import re

def unpack_from_variable_length_string(fmt, data, offset = 0):
    (byte_order, fmt, args) = (fmt[0], fmt[1:], ()) if fmt and fmt[0] in ('@', '=', '<', '>', '!') else ('@', fmt, ())
    fmt = filter(None, re.sub("p", "\tp\t",  fmt).split('\t'))
    for sub_fmt in fmt:
        if sub_fmt == 'p':
            (str_len,) = struct.unpack_from('B', data, offset)
            sub_fmt = str(str_len + 1) + 'p'
            sub_size = str_len + 1
        else:
            sub_fmt = byte_order + sub_fmt
            sub_size = struct.calcsize(sub_fmt)
            print(sub_fmt)
            print(sub_size)
            print(offset)
        args += struct.unpack_from(sub_fmt, data, offset)
        offset += sub_size
    return args

print(unpack_from_variable_length_string('p', b'\x07asdfsdf', 0))
