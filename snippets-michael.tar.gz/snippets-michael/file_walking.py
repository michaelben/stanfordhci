# 4582550
# file walking in python
import os

def file_walking():
    def x(f):
        pass
    def xc(f):
        pass
    for dirpath, dnames, fnames in os.walk("./"):
        for f in fnames:
            if f.endswith(".x"):
                x(os.path.join(dirpath, f))
            elif f.endswith(".xc"):
                xc(os.path.join(dirpath,f))
# Test
file_walking()
