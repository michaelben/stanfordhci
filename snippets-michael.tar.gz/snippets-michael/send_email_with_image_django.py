# 21861593
# creating a MIME email template with images to send with python / django
import django
from django.core.mail import EmailMessage
from django.conf import settings
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email_with_image_django(imgfile, subject='Subject', textbody='This is a test', sender='foo@bar.com', receivers=['bar@foo.com']):
    # The following 2 lines are for testing purpose.
    # The mail sent is displayed to console stdout.
    settings.configure(EMAIL_BACKEND='django.core.mail.backends.console.EmailBackend')
    django.setup()

    # Load the image you want to send as bytes
    img_data = open(imgfile, 'rb').read()

    # Create a "related" message container that will hold the HTML 
    # message and the image. These are "related" (not "alternative")
    # because they are different, unique parts of the HTML message,
    # not alternative (html vs. plain text) views of the same content.
    html_part = MIMEMultipart(_subtype='related')

    # Create the body with HTML. Note that the image, since it is inline, is 
    # referenced with the URL cid:myimage... you should take care to make
    # "myimage" unique
    body = MIMEText('<p>Hello <img src="cid:myimage" /></p>', _subtype='html')
    html_part.attach(body)

    # Now create the MIME container for the image
    img = MIMEImage(img_data, 'jpeg')
    img.add_header('Content-Id', '<myimage>')  # angle brackets are important
    img.add_header("Content-Disposition", "inline", filename="myimage")
    html_part.attach(img)

    msg = EmailMessage(subject, textbody, sender, receivers)
    msg.attach(html_part)
    msg.send()
# Test
send_email_with_image_django('Desert.jpg.1')
