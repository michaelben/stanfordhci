# 3310614
# Remove whitespaces in XML string
from lxml import etree
def remove_whitespaces_xml(xmlstr):
    parser = etree.XMLParser(remove_blank_text=True)
    elem = etree.XML(xmlstr, parser=parser)
    return etree.tostring(elem)
# Test
print(remove_whitespaces_xml('''<root>
        <head></head>
        <content></content>
    </root>'''))
