# 1859072
# Python: Continuing to next iteration in outer loop

def for_else_demo():
    for ii in range(6):
        for jj in range(3):
            print("block0") 
            if ii > 3:
                break
        else:
            print("block1") 

# Break will break the inner loop, and block1 won't be executed (it will run only if the inner loop is exited normally).
for_else_demo()
