# 3402346
# python dict remove duplicate values by key's value
import itertools as it

def remove_duplicate_dict_values(dic):
    newdic = {}
    for v, grp in it.groupby(sorted((v, k) for k, v in dic.items())):
        newdic[min(k for _, k in grp)] = v
    return newdic
# Test
print(remove_duplicate_dict_values({
     1: 'a', 
      2: 'a', 
       3: 'b', 
        4: 'a', 
         5: 'c', 
          6: 'd', 
           7: 'd', 
            8: 'a', 
             9: 'a'}))
