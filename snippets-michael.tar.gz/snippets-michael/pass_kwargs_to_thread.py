# 6904487
# Python, pass a variable by name to a Thread
import threading
def pass_kwargs_to_thread():
    def _thread_function(arg1, arg2=None, arg3=None):
        pass
    arg1 = 'arg1'
    arg2 = 'arg2'
    threading.Thread(target=_thread_function, args=(arg1,),
                             kwargs={'arg2':arg2}, name='thread_function').start()
# Test
pass_kwargs_to_thread()
