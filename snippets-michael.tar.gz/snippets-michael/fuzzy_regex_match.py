# 2420412
# Search for string allowing for one mismatch in any location of the string
import sys
def fuzzy_regex_match():
    try:
        import regex
    except:
        print('this function needs regex installed')
        sys.exit(-1)

    m=regex.findall("AA", "CAG")
    print(m)
    m=regex.findall("(AA){e<=1}", "CAAG") # means allow up to 1 error
    print(m)
# Test
fuzzy_regex_match()
