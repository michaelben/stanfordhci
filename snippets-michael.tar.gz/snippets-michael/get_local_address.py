# 7334349
# Get local IP-Address used to send IP data to a specific remote IP-Address
import socket
def get_local_address(host):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    try:
        s.connect((host, 9))
        client = s.getsockname()[0]
    except socket.error:
        client = "Unknown IP"
    finally:
        del s
    return client
# Test
print(get_local_address('www.baidu.com'))
