# 6351186
# Reading a CSV files columns directly into variables names

import csv

def csv_cols_to_vars(csv_file, numcols):
    csvFile = csv.reader(open(csv_file, "r"))
    myDict = {}
    for i in range(numcols):
        myDict['Col'+str(i+1)] = []
    for row in csvFile:
        for i in range(numcols):
            myDict['Col'+str(i+1)].append(row[i])
    return myDict

print(csv_cols_to_vars("test.csv.1", 3))
