# 8546245
# Concat string in list with space

def concat_str_in_list(myList):
    return ' '.join(myList)

print(concat_str_in_list(['hello', 'good', 'morning']))
