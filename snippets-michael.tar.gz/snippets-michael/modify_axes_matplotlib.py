# 6267008
# Modifying axes on matplotlib colorbar plot of 2D array
import matplotlib.pyplot as plt
import numpy as np

def modify_axes_matplotlib():
    x,y = np.mgrid[-2:2:0.1, -2:2:0.1]
    data = np.sin(x)*(y+1.05**(x*np.floor(y))) + 1/(abs(x-y)+0.01)*0.03

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ticks_at = [-abs(data).max(), 0, abs(data).max()]
    cax = ax.imshow(data, interpolation='nearest', 
                    origin='lower', extent=[0.0, 0.1, 0.0, 0.1],
                    vmin=ticks_at[0], vmax=ticks_at[-1])
    cbar = fig.colorbar(cax,ticks=ticks_at,format='%1.2g')
    fig.savefig('out.png')
# Test
modify_axes_matplotlib()
