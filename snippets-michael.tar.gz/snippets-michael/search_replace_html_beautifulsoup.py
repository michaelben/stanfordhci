# 2073541
# Search and Replace in HTML with BeautifulSoup
from bs4 import BeautifulSoup, Tag
def search_replace_html_beautifulsoup(data):
    soup = BeautifulSoup(data, 'lxml')
    for a in soup.findAll('a'):
        p = Tag(soup, name='p') #create a P element
        a.replaceWith(p)   #Put it where the A element is
        p.insert(0, a)     #put the A element inside the P (between <p> and </p>)
# Test
search_replace_html_beautifulsoup('<body>blah <a href="foo">blah</a> blah</body>')
