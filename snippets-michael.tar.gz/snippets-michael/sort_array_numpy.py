# 14875248
# Python, numpy sort array
import numpy as np
def sort_array_numpy(arr):
    brr = np.reshape(arr, arr.shape[0]*arr.shape[1])
    brr.sort()
    return brr[::-1]
# Test
print(sort_array_numpy(np.random.random((10,15))))
