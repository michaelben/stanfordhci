# 3335342
# Check if a MySQL connection is closed in Python
def check_db_connection(conn):
    if conn.open:
        print('connection is open')
    else:
        print('connection is closed')
# Test
