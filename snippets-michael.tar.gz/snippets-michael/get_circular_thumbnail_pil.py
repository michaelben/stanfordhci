# 890051
# Generate circular thumbnails with PIL
from PIL import Image, ImageOps, ImageDraw

def get_circular_thumbnail_pil(srcimg, destimg, w, h):
    size = (w, h)
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask) 
    draw.ellipse((0, 0) + size, fill=255)
    im = Image.open(srcimg)
    output = ImageOps.fit(im, mask.size, centering=(0.5, 0.5))
    output.putalpha(mask)
    output.save(destimg)
# Test
get_circular_thumbnail_pil('Desert.jpg.2.1', 'output.png.1', 128, 128)
