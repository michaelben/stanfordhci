# 16389938
# Using Selenium in the background
import shutil, sys
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

def selenium_phantomjs():
    p = shutil.which('phantomjs')
    if not p:
        print('phantomjs needed')
        sys.exit(-1)

    driver = webdriver.PhantomJS("phantomjs") # path to phantomjs binary
    driver.get("https://ps.rsd.edu/public/")

    elem = driver.find_element_by_name("account")
    elem.send_keys("Username")
    elem2 = driver.find_element_by_name("pw")
    elem2.send_keys("Password")
    elem.send_keys(Keys.RETURN)

    driver.quit()
# Test
selenium_phantomjs()
