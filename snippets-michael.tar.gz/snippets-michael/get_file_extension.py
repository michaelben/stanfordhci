# 6525334
# Getting file extension using pattern matching in python
import re
def get_file_extension(fname):
    return re.compile(r'^.*?[.](?P<ext>tar\.gz|tar\.bz2|\w+)$').match(fname).group('ext')
# Test
print(get_file_extension('a.tar.gz'))
