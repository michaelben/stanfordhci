# 1869885
# Calculating SHA1 of a file

import hashlib

def hashfile(filepath):
    sha1 = hashlib.sha1()
    f = open(filepath, 'rb')
    try:
        sha1.update(f.read())
    finally:
        f.close()
    return sha1.hexdigest()

print(hashfile("hashfile.py"))
