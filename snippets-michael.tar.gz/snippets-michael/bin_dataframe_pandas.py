# 16947336
# binning a dataframe in pandas in Python
import numpy as np
import pandas as pd

def bin_dataframe_pandas(df):
    # Bin the data frame by "a" with 10 bins...
    bins = np.linspace(df.a.min(), df.a.max(), 10)
    groups = df.groupby(pd.cut(df.a, bins))
    # Get the mean of b, binned by the values in a
    return groups.mean().b
# Test
print(bin_dataframe_pandas(pd.DataFrame({"a": np.random.random(100), 
                       "b": np.random.random(100) + 10})))
