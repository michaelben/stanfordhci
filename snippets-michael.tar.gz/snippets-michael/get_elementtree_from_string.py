# 8580234
# Python ElementTree: Parsing a string and getting ElementTree instance
from xml.etree.ElementTree import fromstring, ElementTree
def get_elementtree_from_string(xmlstr):
    return ElementTree(fromstring(xmlstr))
# Test
print(get_elementtree_from_string('<xml><body>test</body></xml>'))
