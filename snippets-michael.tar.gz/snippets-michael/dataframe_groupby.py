# 11391969
# group pandas DataFrame entries by date in a non-unique column
import pandas as pd
import datetime

def dataframe_groupby(df, date):
    return df.groupby(df[date].map(lambda x: x.year))
# Test
print(list(dataframe_groupby(pd.DataFrame({'date':[datetime.datetime(2000,10,1)
    ,datetime.datetime(2001,10,1)
    ,datetime.datetime(2000,11,1)
    ,datetime.datetime(2001,11,1)]}), 'date')))
