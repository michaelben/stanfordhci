# 9003522
# writing command line output to file
import os
def redirect_output(cmd, fname):
    os.system(cmd + ' > ' + fname)
# Test
redirect_output('ls', 'out.txt')
