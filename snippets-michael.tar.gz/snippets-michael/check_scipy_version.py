# 21385196
# Check the version of scipy
import scipy

def check_scipy_version():
    print(scipy.__version__)
# Test
check_scipy_version()
