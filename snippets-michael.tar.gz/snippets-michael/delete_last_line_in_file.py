# 1877999
# Delete final line in file

import os, sys

def delete_last_line_in_file(file):
    readFile = open(file)
    lines = readFile.readlines()
    readFile.close()

    w = open(file,'w')
    w.writelines(lines[:-1])
    w.close()

delete_last_line_in_file("test_file")
