# 5320871
# In List of Dicts, find min() value of a common Dict field
def get_min_value_dict_field(mydict):
    return min(d['price'] for d in mydict)
# Test
print(get_min_value_dict_field([{'price': 99, 'barcode': '2342355'}, {'price': 88, 'barcode': '2345566'}]))
