# 2452321
# Create a duplicate of an array
import copy
def deepcopy_array(arr):
    return copy.deepcopy(arr)
# Test
print(deepcopy_array([[0,1],[1,2]]))
