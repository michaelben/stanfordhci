# 135664
# Get how many bytes per element in a Python list (tuple)
import sys
def get_size_of(obj):
    return sys.getsizeof(obj)
# Test
print(get_size_of(list(range(1000000))))
