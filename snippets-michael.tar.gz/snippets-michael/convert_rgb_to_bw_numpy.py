# 18777873
# Convert RGB to black OR white
from PIL import Image 
import numpy as np
def convert_rgb_to_bw_numpy(src, dest):
    col = Image.open(src)
    gray = col.convert('L')
    bw = np.asarray(gray).copy()
    bw[bw < 128] = 0    # Black
    bw[bw >= 128] = 255 # White
    imfile = Image.fromarray(bw)
    imfile.save(dest)
# Test
convert_rgb_to_bw_numpy('Desert.jpg.2', 'Desert_bw_numpy.jpg')
