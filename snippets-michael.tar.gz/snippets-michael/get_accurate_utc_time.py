# 1599060
# Get an accurate UTC time with Python
import datetime
import sys

def get_accurate_utc_time():
    try:
        import ntplib
    except:
        print('you need ntplib installed to run this function')
        sys.exit(-1)

    x = ntplib.NTPClient()
    t = datetime.datetime.utcfromtimestamp(x.request('europe.pool.ntp.org').tx_time)
    print(t)
# Test
get_accurate_utc_time()
