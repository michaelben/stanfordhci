# 6633523
# Convert a string with dot and comma into a float number

def to_float(s):
    return float(s.replace(',',''))

print(to_float("123,456.908"))
