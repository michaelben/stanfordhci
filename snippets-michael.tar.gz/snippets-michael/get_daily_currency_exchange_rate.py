# 15250455
# Parse html table with python and beautifulsoup and write to csv
import urllib.request
from bs4 import BeautifulSoup
import csv

def get_daily_currency_exchange_rate(csv_file='currency.csv'):
    contenturl = "http://www.bank.gov.ua/control/en/curmetal/detail/currency?period=daily"
    soup = BeautifulSoup(urllib.request.urlopen(contenturl).read())
    table = soup.find('div', attrs={'class': 'content'})
    rows = table.findAll('tr')
    csv_writer = csv.writer(open(csv_file, 'w'))
    for tr in rows:
        cols = tr.findAll('td')
        if 'cell_c' in cols[0]['class']:
            # currency row
            digital_code, letter_code, units, name, rate = [c.text for c in cols]
            csv_writer.writerow((digital_code, letter_code, units, name, rate))
# Test
get_daily_currency_exchange_rate()
