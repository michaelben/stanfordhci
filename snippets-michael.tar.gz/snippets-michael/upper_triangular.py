# 8905501
# Extract upper/lower triangular part of a numpy matrix
import numpy as np
def upper_triangular(arr):
    return np.triu(arr, -1)
# Test
print(upper_triangular([[1,2,3],[4,5,6],[7,8,9],[10,11,12]]))
