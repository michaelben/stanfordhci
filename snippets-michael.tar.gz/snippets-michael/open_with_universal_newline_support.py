# 1785233
# Convert \r text to \n so readlines() works as intended
def open_with_universal_newline_support(fname):
    return open(fname, 'rU')
# Test
open_with_universal_newline_support('open_with_universal_newline_support.py')
