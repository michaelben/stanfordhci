# 288546
# Connect to Exchange mailbox

import smtplib

def connect_to_exchange_mailbox(server, port, username=None, password=None):
    conn = smtplib.SMTP(server, port)
    conn.starttls()
    conn.login(username, password)
    return conn

# Make sure to enable "Allow less secure apps"
# on your gmail account security seeting if no 2FA enabled,
# or issue single use password for apps if 2FA is enabled.
# Otherwise gmail may block you accessing from script!
print(connect_to_exchange_mailbox("smtp.gmail.com", 587, username="username", password="password"))
