# 6407780
# Extract data from JSON Object in Python
import json
def extract_data_from_json():
    print(json.loads('{"foo": 42, "bar": "baz"}')[u'bar'])
# Test
extract_data_from_json()
