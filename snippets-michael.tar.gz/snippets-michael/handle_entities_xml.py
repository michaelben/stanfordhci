# 5170252
# The best way to handle &nbsp;-like entities in XML documents with lxml
from lxml import etree
from io import StringIO
def handle_entities_xml(x):
    p = etree.XMLParser(remove_blank_text=True, resolve_entities=False)
    r = etree.parse(StringIO(x), p)
    return etree.tostring(r) # '<aa>&nbsp;&acirc;</aa>'
# Test
print(handle_entities_xml("""<?xml version="1.0"?>\n<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >\n<aa>&nbsp;&acirc;</aa>"""))
