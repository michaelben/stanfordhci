# 14951356
# Django : Testing if the page has redirected to the desired url
from django.test import SimpleTestCase
def test_page_redirect_django(response, expected_url, status_code=302, target_status_code=200):
    SimpleTestCase.assertRedirects(response, expected_url, status_code=status_code, target_status_code=target_status_code, host=None, msg_prefix='', fetch_redirect_response=True)
# Test
