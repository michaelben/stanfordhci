# 9427163
# Remove duplicate dict in list in Python
def remove_duplicate_dict_in_list(l):
    return [dict(t) for t in set([tuple(d.items()) for d in l])]
# Test
print(remove_duplicate_dict_in_list([{'a': 123, 'b': 1234}, {'a': 3222, 'b': 1234}, {'a': 123, 'b': 1234}]))
