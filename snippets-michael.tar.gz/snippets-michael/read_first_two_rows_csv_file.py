# 7661540
# Print the first two rows of a csv file to a standard output
import csv
from io import StringIO
def read_first_two_rows_csv_file(csv_file_fd):
    csvReader = csv.reader(csv_file_fd)
    for i, row in enumerate(csvReader):
        if i < 2:
            print(row)
        else:
            break
# Test
read_first_two_rows_csv_file(StringIO('''\
        1,2,3
        4,5,6
        7,8,9'''))
