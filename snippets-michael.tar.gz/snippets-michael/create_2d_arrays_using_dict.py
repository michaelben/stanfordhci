# 9497322
# Create 2D arrays in Python
def create_2d_arrays_using_dict():
    player_dict_info = {'x':0, 'y':0, 'ammo':0}
    enemy_dict_info = {'x':0, 'y':0, 'ammo':0}
    information_state = {'player': player_dict_info, 'enemy': enemy_dict_info}
    return information_state
# Test
print(create_2d_arrays_using_dict())
