# 9602856
# Most efficient way to split strings in Python
def efficient_string_split(input):
    res0 = input.split("|")
    res1, res2 = [], []
    for r in res0:
        if "<>" in r:
            res2.append(r.split("<>"))
        else:
            res1.append(r)
    return res1, res2
# Test
print(efficient_string_split('a|b|c|de|f<>ge<>ah'))
