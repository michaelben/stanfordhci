# 8018973
# Iterate through dictionary in a dictionary in django template

def iterate_dict_dict_django_template(data):
    return '''
	<table>
	    <tr>
		<td>a</td>
		<td>b</td>
		<td>c</td>
	    </tr>

	    {% for key, values in data.items %}
	    <tr>
		<td>{{key}}</td>
		{% for k, v in values.items %}
		<td>{{k}}</td>
		<td>{{v}}</td>
		{% endfor %}
	    </tr>
	    {% endfor %}
	</table>
	'''

print(iterate_dict_dict_django_template({'a': {'aa': 1, 'ab': 2}, 'b': {'ba': 3, 'bb': 4},'c': {'ca': 5, 'cb': 6}}))
