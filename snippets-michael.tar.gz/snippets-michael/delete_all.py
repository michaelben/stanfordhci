# 14465279
# Delete all objects in a list

def delete_all(myList):
    del myList[:]
    return myList

print(delete_all(list(range(10000))))
