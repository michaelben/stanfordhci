# 5400275
# fast, large-width, non-cryptographic string hashing in python
import smhasher

def fast_large_noncrypt_hash(s):
    '''smhasher can be downloaded from https://github.com/phensley/python-smhasher'''
    return smhasher.murmur3_x64_128(s)
# Test
print(fast_large_noncrypt_hash('samplebias'))
