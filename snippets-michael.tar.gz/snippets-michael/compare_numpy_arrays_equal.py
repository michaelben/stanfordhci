# 6628793
# Comparing elements of numpy arrays in python
import numpy as np
def compare_numpy_arrays_equal(arr1, arr2):
    return (arr1 == arr2).all()
# Test
print(compare_numpy_arrays_equal(np.array([ 150, 25, 75]), [150,25,75]))
