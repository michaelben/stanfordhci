# 10011707
# Get NaN when I divide by zero
import numpy
def get_inf_if_divide_by_zero():
    return numpy.float64(1.0)/0.0
# Test
print(get_inf_if_divide_by_zero())
