# 2270874
# Average image color detection

from PIL import Image

def average_image_color(filename):
    i = Image.open(filename)
    h = i.histogram()

    # split into red, green, blue
    r = h[0:256]
    g = h[256:256*2]
    b = h[256*2: 256*3]

    # perform the weighted average of each channel:
    # the *index* is the channel value, and the *value* is its weight
    sum_r = sum(r)
    sum_g = sum(g)
    sum_b = sum(b)
    return (
        sum( i*w for i, w in enumerate(r) ) / sum_r if sum_r > 0 else 0,
        sum( i*w for i, w in enumerate(g) ) / sum_g if sum_g > 0 else 0,
        sum( i*w for i, w in enumerate(b) ) / sum_b if sum_b > 0 else 0
    )

print(average_image_color("Desert.jpg"))
