# 7429118
# Get all the values from a numpy array excluding a certain index
import numpy as np

def exclude_mask_numpy():
    a = np.array([0,1,2,3,4,5,5,6,7,8,9])
    print(a)
    print(a.sum())

    a = np.ma.array(a, mask=False)
    a.mask[3] = True
    print(a)
    print(a.sum())

    print(a.compressed())
# Test
exclude_mask_numpy()
