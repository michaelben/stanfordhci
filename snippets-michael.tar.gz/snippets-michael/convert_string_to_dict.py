# 10978908
# Converting a string to dictionary in python
def convert_string_to_dict(str):
    return dict([str.strip('{}').split(":"),])
# Test
print(convert_string_to_dict("{application.root.category.id:2}"))
