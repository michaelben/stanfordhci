# 1356029
# line up text from python into columns in my terminal
def line_up_text_columns(name, price):
    print("Name: %-20s Price: %10d" % (name, price))
# Test
line_up_text_columns('name', 245)
