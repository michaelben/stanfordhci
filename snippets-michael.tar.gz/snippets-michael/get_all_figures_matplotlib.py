# 3783217
# Get the list of figures in matplotlib

import numpy as np
import pylab
import matplotlib._pylab_helpers

def get_all_figures_matplotlib():
    x=np.random.random((10,10))
    y=np.random.random((10,10))
    pylab.figure()
    pylab.plot(x)
    pylab.figure()
    pylab.plot(y)

    figures=[manager.canvas.figure
             for manager in matplotlib._pylab_helpers.Gcf.get_all_fig_managers()]
    print(figures)

    #for i, figure in enumerate(figures):
    #    figure.savefig('figure%d.png' % i)

# Test
get_all_figures_matplotlib()
