# 8124606
# Create excel-compatable CSV file with python
import csv

def write_excel_compatable_csv(csvfile, data):
    def quoteCsvData(data):
        for x, row in enumerate(data):
            for y, item in enumerate(row):
                 if data[x][y] != '':
                     data[x][y] = r'="' + data[x][y] + r'"'
        return data

    data = quoteCsvData(data)
    with open(csvfile, 'w') as fd:
        writer = csv.writer(fd, delimiter=',',
                                quotechar='|', 
                                quoting=csv.QUOTE_NONE, 
                                escapechar='\\')
        writer.writerows(data)
# Test
write_excel_compatable_csv('test2.csv', [ ['9-1', '9-2', '9-3'] ])
