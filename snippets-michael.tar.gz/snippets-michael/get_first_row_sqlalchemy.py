# 18110033
# Getting first row from sqlalchemy
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.orm.exc import MultipleResultsFound

def get_first_row_sqlalchemy(session):
    try:
        user = session.query(User).one()
    except MultipleResultsFound as e:
        print(e)
        # Deal with it
    except NoResultFound as e:
        print(e)
        # Deal with that as well
# Test
