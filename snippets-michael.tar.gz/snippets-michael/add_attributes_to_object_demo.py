# 2827623
# Adding attributes to python objects
def add_attributes_to_object_demo():
    class Obj:
        def __init__(self, a=None):
            self.a = a
    obj = Obj()
    obj.a = lambda: None
    setattr(obj.a, 'somefield', 'somevalue')
    print(obj.a.somefield)
# Test
add_attributes_to_object_demo()
