# 17133000
# Obtaining length of list as a value in dictionary
def value_length_dict(d):
    for k in d.keys():
        print(len(d[k]))
# Test
value_length_dict({1:[1,2,3,4], 2:[5,6,7]})
