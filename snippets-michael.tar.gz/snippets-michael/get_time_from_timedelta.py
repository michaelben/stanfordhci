# 764184
# Python: Get time from a datetime.timedelta object
import datetime
def get_time_from_timedelta():
    value = datetime.timedelta(0, 64800)
    return (datetime.datetime.min + value).time()
# Test
print(get_time_from_timedelta())
