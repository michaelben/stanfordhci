# 2262879
# Converting from ascii to utf-8 with Python
import sys
def get_system_stdout_encoding():
    return sys.stdout.encoding
# Test
print(get_system_stdout_encoding())
