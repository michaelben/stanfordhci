# 19252301
# creating a new list with subset of list using index in python
def chain_elements_or_slices(*elements_or_slices):
    new_list = []
    for i in elements_or_slices:
        if isinstance(i, list):
            new_list.extend(i)
        else:
            new_list.append(i)
    return new_list
# Test
a = ['a', 'b', 'c', 3, 4, 'd', 6, 7, 8]
print(chain_elements_or_slices(a[0:2], a[4], a[6:]))
