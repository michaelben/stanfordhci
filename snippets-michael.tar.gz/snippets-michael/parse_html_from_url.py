# 9783875
# lxml in python, parse from url
import requests
from lxml import html
def parse_html_from_url(url):
    res = requests.get(url)
    doc = html.fromstring(res.content)
    return doc
# Test
print(parse_html_from_url('http://www.wikipedia.org'))
