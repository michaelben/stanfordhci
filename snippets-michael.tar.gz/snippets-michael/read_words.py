# 13259288
# returning a list of words after reading a file in python
def read_words(words_file):
    return [word for line in open(words_file, 'r') for word in line.split()]
# Test
print(read_words('read_words.py'))
