# 6431973
# Copy data from a numpy array to another

import numpy

def numpy_copyto(b):
    a = numpy.empty_like (b)
    a[:] = b
    return a

numpy_copyto(numpy.arange(10))
