# 15083119
# python - find the occurrence of the word in a file
from collections import Counter

def find_words_occurrence(words):
    c = Counter()
    for line in words.splitlines():
        c.update(line.split())
    return c
# Test
print(find_words_occurrence('''\
        ashwin programmer india
        amith programmer india'''))
