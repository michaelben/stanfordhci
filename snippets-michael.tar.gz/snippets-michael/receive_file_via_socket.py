# 9382045
# Receive file through sockets

import socket
import tmpfile

def receive_file_via_sockets(host, port):
    s = socket.socket()
    s.bind((host, port))
    s.listen(10)

    while True:
        sc, address = s.accept()

        print(sc)
        print(address)
        fn = tmpfile.tmpfile().name
        f = open(fn,'wb')
        while True:
            l = sc.recv(1024)
            if not l:
                break
            f.write(l)
        f.close()

        print("outfile is at: " + fn)
        sc.close()

    s.close()

receive_file_via_sockets("localhost", 9999)
