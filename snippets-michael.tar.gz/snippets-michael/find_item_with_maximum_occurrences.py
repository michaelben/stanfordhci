# 6987285
# Python - find the item with maximum occurrences
from collections import defaultdict

def find_item_with_maximum_occurrences(L):
    d = defaultdict(int)
    for i in L:
        d[i] += 1
    result = max(d.items(), key=lambda x: x[1])
    print(result)
# Test
find_item_with_maximum_occurrences([1,2,45,55,5,4,4,4,4,4,4,5456,56,6,7,67])
