# 1759619
# Remove &#13; from python string
def replace_cr_lf(s):
    return s.replace('\r\n', '\n')
# Test
print(replace_cr_lf('  Now is the time for all good...  \t\n\r   '))
