# 14049983
# Selenium Webdriver finding an element in a sub-element
from selenium import webdriver
def find_element_in_subelement(url):
    driver = webdriver.Firefox()
    driver.get(url)
    element2 = driver.find_element_by_xpath("//div[@title='div2']")
    return element2.find_element_by_xpath(".//p[@class='test']").text 
# Test
print(find_element_in_subelement('http://michaelben.github.io/product-catalog-demo/test/test.html'))
