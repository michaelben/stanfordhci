# 7724993
# Using regex to find multiple matches and print them out

import re

def find_all(pattern, line):
	return re.findall(pattern, line, re.DOTALL)

print(find_all('<form>(.*?)</form>', 'bla bla bla<form>Form 1</form> some text...<form>Form 2</form> more text?'))
