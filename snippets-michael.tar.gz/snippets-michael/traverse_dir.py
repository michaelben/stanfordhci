# 4918458
# Traverse through the files in a directory
import os
def traverse_dir(folder, recursive=False):
    if recursive:
        return os.walk(folder)
    else:
        return os.listdir(folder)
# Test
print(traverse_dir('.'))
