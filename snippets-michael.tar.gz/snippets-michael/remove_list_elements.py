# 7459246
# Deleting array elements in python
def remove_list_elements(A, B):
    return [x for x in B if x not in A]
# Test
print(remove_list_elements(['at','in','the'], ['verification','at','done','on','theresa']))
