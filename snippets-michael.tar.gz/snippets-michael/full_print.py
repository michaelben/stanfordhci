# 19124601
# (pretty) print the entire Pandas Series / DataFrame
import pandas as pd
import numpy as np
def full_print(df):
    pd.set_option('display.max_rows', len(df))
    print(df)
    pd.reset_option('display.max_rows')
# Test
full_print(pd.DataFrame(np.random.rand(100)))
