# 10937918
# Loading a file into a numpy array with python

import numpy as np

def load_csv_numpy(csv_file, delimiter=","):
    return np.loadtxt(csv_file, delimiter=delimiter)

print(np.matrix(load_csv_numpy("test.csv.1")))
