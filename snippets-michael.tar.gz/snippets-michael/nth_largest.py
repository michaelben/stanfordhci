# 1034846
# Finding Nth item of unsorted list without sorting the list
import heapq
import random

def nth_largest(n, iter):
    return heapq.nlargest(n, iter)[-1]
# Test
print(nth_largest(10, [random.randint(0,1000) for i in range(100)]))
