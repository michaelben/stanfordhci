# 4918425
# Subtract a value from every number in a list

def subtract_value_from_list(myList, value):
    return [x - value for x in myList]

print(subtract_value_from_list([49, 51, 53, 56], 13))
