# 875968
# Python regex remove string
import re
def remove_non_word_from_string(s):
    return re.sub(r'[^\w]', ' ', s)
# Test
print(remove_non_word_from_string("how much for the maple syrup? $20.99? That's ricidulous!!!"))
