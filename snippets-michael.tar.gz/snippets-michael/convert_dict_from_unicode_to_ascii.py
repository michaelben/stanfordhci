# 13101653
# Python: Convert complex dictionary of strings from Unicode to ASCII
def convert_dict_from_unicode_to_ascii(input):
    if isinstance(input, dict):
        return dict((convert_dict_from_unicode_to_ascii(key), convert_dict_from_unicode_to_ascii(value)) for key, value in input.items())
    elif isinstance(input, list):
        return [convert_dict_from_unicode_to_ascii(element) for element in input]
    elif isinstance(input, str):
        return input.encode('utf-8')
    else:
        return input
# Test
print(convert_dict_from_unicode_to_ascii({u'asdf':[u'sdf',u'2wer']}))
