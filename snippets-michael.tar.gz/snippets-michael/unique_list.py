# 12878833
# Python unique list using OrderedDict, more efficient then using set

from collections import OrderedDict

def unique_list(myList):
	return list(OrderedDict.fromkeys(myList).keys())

print(unique_list([1, 2, 3, 'a', 2, 4, 'a']))
