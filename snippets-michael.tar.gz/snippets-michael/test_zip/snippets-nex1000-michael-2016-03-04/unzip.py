# 19483775
# Python zipfile.extract() doesn't extract all files
import zipfile
def unzip(source_filename, dest_dir):
    with zipfile.ZipFile(source_filename) as zf:
        zf.extractall(dest_dir)
# Test
unzip('test.zip', 'test_zip')
