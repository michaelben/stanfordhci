# 18504967
# pandas dataframe create new columns and fill with calculated values from same df
import numpy as np
import pandas as pd
def add_computed_cols_pandas(ds, rsuffix='_prec'):
    ds['sum']=ds.sum(axis=1)
    return ds.join(ds.div(ds['sum'], axis=0), rsuffix=rsuffix)
# Test
print(add_computed_cols_pandas(pd.DataFrame(np.abs(np.random.randn(3, 4)), index=[1,2,3], columns=['A','B','C','D'])))
