# 4082772
# Return a list of weekdays starting from the given weekday
def weekdays(day):
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    i=days.index(day) # get the index of the selected day
    d1=days[i:] #get the list from an including this index
    d1.extend(days[:i]) # append the list form the beginning to this index
    return d1
# Test
print(weekdays("Wednesday"))
