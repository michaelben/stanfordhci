# 216119
# Reverse a list using recursion in Python
def reverse_list_recursion(l):
    return [l[-1]] + reverse_list_recursion(l[:-1]) if l else []
# Test
print(reverse_list_recursion([1, 2, 3, 4, 5]))
