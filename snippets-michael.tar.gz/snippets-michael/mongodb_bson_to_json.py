# 11867538
# Transform MongoDB's bsondump into JSON
import json, re
import sys

def mongodb_bson_to_json(bsondata):
    try:
        from bson import json_util
    except:
        print('mongoDB Extended JSON in TenGen mode is needed')
        sys.exit(-1)

    jsondata = re.sub(r'ObjectId\s*\(\s*\"(\S+)\"\s*\)',
                      r'{"$oid": "\1"}',
                      bsondata)
    jsondata = re.sub(r'Date\s*\(\s*(\S+)\s*\)',
                      r'{"$date": \1}',
                      jsondata)

    data = json.loads(jsondata, object_hook=json_util.object_hook)
    return json_util.dumps(data)
# Test
print(mongodb_bson_to_json('''
        { "_id" : ObjectId( "4d9b642b832a4c4fb2000000" ),
          "acted_at" : Date( 1302014955933 ),
          "created_at" : Date( 1302014955933 ),
          "updated_at" : Date( 1302014955933 ),
          "_platform_id" : 3,
          "guid" : 72106535190265857 }'''))
