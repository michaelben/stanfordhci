# 10862471
# Writing a numpy array to a CSV File
import numpy as np
def save_csv_numpy(fname, X, delimiter=','):
    np.savetxt(fname, X, delimiter=delimiter)
# Test
save_csv_numpy('numpy.csv', np.array([[1,2,3],[4,5,6]]))
