# 6141853
# numpy array of objects
import numpy as np
def object_array_numpy(obj):
    return np.array(obj, dtype=object)
# Test
print(object_array_numpy(['hello', 'world!']))
