# 13572448
# Change values in a numpy array
import numpy as np
def change_values_in_array_numpy(a, palette, key):
    '''
    palette must be given in sorted order
    key gives the new values you wish palette to be mapped to.
    '''
    index = np.digitize(a.ravel(), palette, right=True)
    return key[index].reshape(a.shape)
# Test
print(change_values_in_array_numpy(np.array([1,2,2,1]).reshape(2,2), [1, 2], np.array([0, 10])))
