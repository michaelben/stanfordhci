# 10565282
# pandas, python - Select specific times in timeseries
from datetime import datetime
import pandas as pd
import numpy as np
def select_times_in_timeseries():
    dr = pd.date_range(datetime(2009,1,1),datetime(2010,12,31), freq='H')
    dtime = pd.DataFrame(np.random.rand(len(dr),2), dr)
    hour = dtime.index.hour
    selector = ((10 <= hour) & (hour <= 13)) | ((20<=hour) & (hour<=23))
    data = dtime[selector]
    print(data)
# Test
select_times_in_timeseries()
