# 2157035
# Python: Accessing an attribute using a variable
from collections import namedtuple
import random

def get_attribute_with_variable():
    Prize = namedtuple("Prize", ["left", "right" ])
    this_prize = Prize("FirstPrize", "SecondPrize")

    if random.random() > .5:
       choice = "left"
    else:
       choice = "right"

    #retrieve the value of "left" or "right" depending on the choice

    print("You won", getattr(this_prize,choice))
# Test
get_attribute_with_variable()
