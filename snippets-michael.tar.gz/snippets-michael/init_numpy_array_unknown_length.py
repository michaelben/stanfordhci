# 10121926
# Initialise numpy array of unknown length
import numpy as np
def init_numpy_array_unknown_length(l):
    return np.array(l)
# Test
print(init_numpy_array_unknown_length([1,2,3]))
