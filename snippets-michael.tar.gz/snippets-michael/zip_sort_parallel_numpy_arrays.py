# 1903462
# zip sort parallel numpy arrays
import numpy as np
def zip_sort_parallel_numpy_arrays(a, b):
    return b[a.argsort()]
# Test
print(zip_sort_parallel_numpy_arrays(np.array([2, 3, 1]), np.array([4, 6, 2])))
