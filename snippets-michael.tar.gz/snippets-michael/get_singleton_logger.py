# 7173033
# Duplicate log output when using Python logging module
import os
import time
import datetime
import logging

def get_singleton_logger(name):
    loggers = {}

    def myLogger(name):
        global loggers

        if loggers.get(name):
            return loggers.get(name)
        else:
            logger = logging.getLogger(name)
            logger.setLevel(logging.DEBUG)
            now = datetime.datetime.now()
            handler = logging.FileHandler(
                now.strftime("%Y-%m-%d") 
                + '.log')
            formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            loggers.update(dict(name=logger))

            return logger

    return myLogger(name)
# Test
