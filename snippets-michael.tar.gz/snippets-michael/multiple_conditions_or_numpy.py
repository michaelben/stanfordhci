# 10377096
# Multiple conditions using 'or' in numpy array
import numpy as np
def multiple_conditions_or_numpy(A):
    return np.where(((A>0) & (A<10)) | ((A>40) & (A<60)),1,0)
# Test
print(multiple_conditions_or_numpy(np.arange(100)))
