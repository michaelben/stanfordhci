# 3246262
# Assign values to letters
def assign_values_to_letters():
    return {chr(i): i + 1 for i in range(ord("a"), ord("a") + 26)}
# Test
print(assign_values_to_letters())
