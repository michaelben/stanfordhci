# 1636637
# Check how large the file size is after downloading using urllib2
import urllib.request
def check_web_file_size():
    f = urllib.request.urlopen("http://dalkescientific.com")
    print(f.headers.items())
    print(f.headers["Content-Length"])
# Test
check_web_file_size()
