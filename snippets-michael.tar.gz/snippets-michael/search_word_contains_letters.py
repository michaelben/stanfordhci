# 9443302
# Search strings in list containing specific letters in random order
def search_word_contains_letters(wordlist, letters):
    letters_set = set(letters)
    for word in wordlist:
        if letters_set & set(word):
            print(word)
# Test
search_word_contains_letters(['mississippi','miss','lake','que'], 'aqk')
