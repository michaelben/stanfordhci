# 20181456
# Sum up column values in Pandas DataFrame
import pandas as pd
def groupby_dataframe_pandas():
    data = {"score":{"0":9.397,"1":9.397,"2":9.397995,"3":9.397996,"4":9.3999},"type":{"0":"advanced","1":"advanced","2":"advanced","3":"newbie","4":"expert"},"count":{"0":394.18930604,"1":143.14226729,"2":9.64172783,"3":0.1,"4":19.65413734}}
    df = pd.DataFrame(data)
    print(df)
    print(df.groupby(["score", "type"]).sum())
# Test
groupby_dataframe_pandas()
