# 10555671
# Rethrow an exception that contains information about an original exception
def rethrow_exception():
    try:
        raise TypeError('foo')
    except TypeError as t:
        raise ValueError(t)
# Test
rethrow_exception()
