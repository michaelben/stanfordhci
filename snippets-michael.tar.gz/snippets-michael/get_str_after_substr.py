# 5108382
# Get a string after a specific substring

def get_str_after_substr(s, sub):
    return s.split(sub, 1)[1]

print(get_str_after_substr("hello python world , i'm a beginner ", 'world'))
