# 5669773
# Export a table to csv or excel format
import csv

def export_db_table_to_csv(connection, csv_file):
    cursor = connection.cursor()
    cursor.execute('select * from table')
    with open(csv_file, 'w') as fout:
        writer = csv.writer(fout)
        writer.writerow([ i[0] for i in cursor.description ]) # heading row
        writer.writerows(cursor.fetchall())
# Test
