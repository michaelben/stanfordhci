# 16927354
# How can I make Selenium/Python wait for the user to login before continuing to run?
import contextlib
import selenium.webdriver as webdriver
import selenium.webdriver.support.ui as ui
def web_driver_wait_selenium():
    with contextlib.closing(webdriver.Firefox()) as driver:
        driver.get('http://www.google.com')
        wait = ui.WebDriverWait(driver, 10) # timeout after 10 seconds
        inputElement = driver.find_element_by_name('q')
        inputElement.send_keys('python')
        inputElement.submit()
        results = wait.until(lambda driver: driver.find_elements_by_class_name('g'))
        for result in results:
            print(result.text)
            print('-'*80)
# Test
web_driver_wait_selenium()
