# 6682284
# Read file names from directory w/ python
import os
def get_all_files_from_folder(folder):
    return [(x[0], x[2]) for x in os.walk(folder)]
# Test
print(get_all_files_from_folder('.'))
