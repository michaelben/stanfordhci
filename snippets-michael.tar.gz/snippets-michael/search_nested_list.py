# 1658505
# searching within nested list in python
def search_nested_list(thelist, anitem, adef=None):
    return next((subl for subl in thelist if anitem in subl), adef)
# Test
print(search_nested_list([['en', 60, 'command'],['sq', 34, 'komand']], 'sq'))
