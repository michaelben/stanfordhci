# 8366276
# Writing a list of tuples to a text file in Python
def write_tuple_list_to_file(tuple_list, f):
    for t in tuple_list:
        f.write(' '.join(str(s) for s in t) + '\n')
# Test
write_tuple_list_to_file([('Apples', '=', 10), ('Oranges', '<', 20)], open('file0412.txt', 'w'))
