# 5663787
# Upload folders from local system to FTP using python script
import ftplib
import os

def upload_dir(dir, server='localhost', username='username', password='password'):
    myFTP = ftplib.FTP(server, username, password)
    myPath = dir
    def uploadThis(path):
        files = os.listdir(path)
        os.chdir(path)
        for f in files:
            if os.path.isfile(os.path.join(path, f)):
                fh = open(f, 'rb')
                myFTP.storbinary('STOR %s' % f, fh)
                fh.close()
            elif os.path.isdir(os.path.join(path, f)):
                myFTP.mkd(f)
                myFTP.cwd(f)
                uploadThis(os.path.join(path, f))
        myFTP.cwd('..')
        os.chdir('..')
    uploadThis(myPath)
# Test
