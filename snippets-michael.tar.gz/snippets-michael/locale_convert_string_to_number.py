# 1779288
# How do I use Python to convert a string to a number if it has commas in it as thousands separators?
import locale
def locale_convert_string_to_number():
    locale.setlocale( locale.LC_ALL, 'en_US.UTF-8' ) 
    print(locale.atoi('1,000,000'))
    print(locale.atof('1,000,000.53'))
# Test
locale_convert_string_to_number()
