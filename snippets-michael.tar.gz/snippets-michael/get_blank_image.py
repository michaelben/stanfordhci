# 12881926
# Create a new RGB OpenCV image

import numpy as np

def get_blank_image(height, width):
    return np.zeros((height,width,3), np.uint8)

get_blank_image(256, 256)
