# 10542240
# test if each element in an numpy array lies between two values
import numpy as np
def all_elements_between_range(a, low, high):
    return (a >= low).all() and (a <= high).all()
# Test
print(all_elements_between_range(np.array([1,2,3,4,5]), 1, 5))
