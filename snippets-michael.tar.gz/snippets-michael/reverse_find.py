# 3537717
# Reverse find in string

def reverse_find(s, sub, start, end):
    return s.rfind(sub, start, end)

print(reverse_find("Hello, I am 12! I like plankton but I don't like Baseball.", 'I', 0, 34))
