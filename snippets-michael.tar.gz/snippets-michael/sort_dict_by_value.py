# 11932729
# Sort a Python dictionary by value
from collections import OrderedDict

def sort_dict_by_value(d):
    return OrderedDict(sorted(d.items(), key=lambda item: item[1][1]))
# Test
print(sort_dict_by_value({ 'e': (1, 100), 'a': (2, 3) }))
