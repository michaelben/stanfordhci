# 3330137
# adjusting heights of individual subplots in matplotlib in Python
import matplotlib.pyplot as plt
def adjust_height_subplots_matplotlib():
    plt.subplot(6,1,1)
    plt.subplot(6,1,2)
    plt.subplot(6,1,3)
    plt.subplot(2,1,2)
    plt.show()
# Test
adjust_height_subplots_matplotlib()
