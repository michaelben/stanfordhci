# 16945518
# Python argmin/argmax: Finding the index of the value which is the min or max
def get_min_indices(items):
    by_index = ([sub_index, list_index] for list_index, list_item in
                         enumerate(items) for sub_index in list_item[0])
    return [item[1] for item in sorted(by_index)]
# Test
print(get_min_indices([([[0, 1], [2, 20]], 'zz', ''), ([[1, 3], [5, 29], [50, 500]], 'a', 'b')]))
