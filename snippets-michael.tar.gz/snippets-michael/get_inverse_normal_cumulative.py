# 20626994
# calculate the inverse of the normal cumulative distribution function
from scipy.stats import norm
from scipy.special import ndtri

def get_inverse_normal_cumulative():
    print(norm.ppf(0.95))
    print(norm.cdf(norm.ppf(0.95)))
    print(norm.ppf(0.95, loc=10, scale=2))
    print(ndtri(0.95))
# Test
get_inverse_normal_cumulative()
