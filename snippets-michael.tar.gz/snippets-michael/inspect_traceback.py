# 2359248
# How can you programmatically inspect the stack trace of an exception in Python?
import sys
import traceback

def inspect_traceback():
    try:
        eval('a')
    except NameError:
        print('BEGIN')
        traceback.print_exc(file=sys.stdout)
        print('END')
# Test
inspect_traceback()
