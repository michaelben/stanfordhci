# 15707056
# Get time of execution of a block of code
import timeit
def get_time_elapsed(code):
    start_time = timeit.default_timer()
    exec(code)
    return timeit.default_timer() - start_time
# Test
print(get_time_elapsed('dir()'))
