# 9012351
# create a list from input in Python 3

def create_list_from_input():
    tempList = []
    while True:
        dailyTemp = input("Enter average daily temperature or -100 to quit: ")
        if dailyTemp == '-100':
            break

        tempList.append(dailyTemp)

    return tempList
# Test
print(create_list_from_input())
