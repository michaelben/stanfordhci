# 5316720
# Convert a list of dictionaries' values into int/float from string

def convert_list_values(theList):
    for sub in theList:
        for key in sub:
            sub[key] = int(sub[key])
    return theList

print(convert_list_values([ { 'a':'1' , 'b':'2' , 'c':'3' }, { 'd':'4' , 'e':'5' , 'f':'6' } ]))
