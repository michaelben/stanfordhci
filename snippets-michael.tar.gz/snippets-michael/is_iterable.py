# 1952464
# Check if an object is iterable

import collections

def is_iterable(o):
    if isinstance(o, collections.Iterable):
        return True
    else:
        return False

print(is_iterable("adfaf"))
