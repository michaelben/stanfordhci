# 1789543
# find number of bytes taken by python variable
import sys
def get_size_of(var):
    return sys.getsizeof(var)
# Test
print(get_size_of(int(12)))
