# 1593274
# Check if the python debug option is set from within a script
import sys
import os

def is_debug_mode_enabled():
    '''
    Python debug mode is enabled with -d commandline option,
    or PYTHONDEBUG environment variable, and starting from 2.6
    is reflected in sys.flags.debug.
    '''
    if os.getenv('PYTHONDEBUG'):
        return True

    if sys.flags.debug:
        return True

    return False
# Test
print(is_debug_mode_enabled())
