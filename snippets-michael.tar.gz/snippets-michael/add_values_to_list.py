# 8922076
# Adding values to a list
import collections
def add_values_to_list():
    thing = collections.defaultdict(list)
    thing[0].append('spam')
    thing[1].append('eggs')
    print(thing)
    print(thing[0])
    print(thing[69])
# Test
add_values_to_list()
