# 19668292
# Python Read Text File Column by Column
import csv
from io import StringIO

def read_csv_file_by_column(csvfile):
    reader = csv.reader(csvfile)
    for column in zip(*reader):
        print(column)
# Test
read_csv_file_by_column(StringIO('''\
    1,989785345,"something 1",,234.34,254.123
    2,234823423,"something 2",,224.4,254.123
    3,732847233,"something 3",,266.2,254.123
    4,876234234,"something 4",,34.4,254.123'''))
