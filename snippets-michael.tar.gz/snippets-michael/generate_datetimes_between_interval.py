# 10688006
# Generate a list of datetimes between an interval in python
from datetime import date, datetime, timedelta

def generate_datetimes_between_interval():
    def perdelta(start, end, delta):
        curr = start
        while curr < end:
            yield curr
            curr += delta
    for result in perdelta(date(2011, 10, 10), date(2011, 12, 12), timedelta(days=4)):
        print(result)
    for result in perdelta(datetime.now(),
        datetime.now().replace(hour=19) + timedelta(days=1),
        timedelta(hours=8)):
        print(result)
# Test
generate_datetimes_between_interval()
