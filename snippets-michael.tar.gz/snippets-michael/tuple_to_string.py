# 3886669
# Tuple to string
def tuple_to_string(t):
    return str(t)
# Test
print(tuple_to_string(([['name', u'bob-21'], ['name', u'john-28']], True)))
