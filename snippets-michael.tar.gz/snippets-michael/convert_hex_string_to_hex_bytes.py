# 10824319
# Convert a string containing hex bytes to a hex string
import binascii
def convert_hex_string_to_hex_bytes(hex):
    return binascii.a2b_hex(hex)
# Test
print(convert_hex_string_to_hex_bytes('356a192b7913b04c54574d18c28d46e6395428ab'))
