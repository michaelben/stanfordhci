# 2356779
# Importing sound files into Python as NumPy arrays (alternatives to audiolab)
from scipy.io import wavfile
def import_sound_files(filename):
    fs, data = wavfile.read(filename)
    return fs, data
# Test
