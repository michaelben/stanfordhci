# 7135836
# Sort python list by function
def sort_list_by_function(s, func):
    s.sort(key=func)
    return s
# Test
print(sort_list_by_function([2,3,1,4], lambda x:x))
