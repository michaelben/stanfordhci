# 4230497
# counting odd numbers in a list python
def count_odd(l):
    if l == list(): return 0
    return l[0] % 2 + count_odd(l[1:])
# Test
print(count_odd([]))
print(count_odd([1, 3, 5]))
print(count_odd([2, 4, 6]))
print(count_odd([0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]))
