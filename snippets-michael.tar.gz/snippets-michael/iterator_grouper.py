# 8991506
# Iterate an iterator by chunks (of n) in Python
import itertools
def iterator_grouper(n, iterable, fillvalue=None):
    "grouper(3, 'ABCDEFG', 'x') --> ABC DEF Gxx"
    args = [iter(iterable)] * n
    return list(itertools.zip_longest(fillvalue=fillvalue, *args))
# Test
print(iterator_grouper(3, [1,2,3,4,5,6,7], 0))
