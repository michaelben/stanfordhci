# 10937350
# Check type of files without extensions

import magic

def filetype(fname):
    return magic.from_file(fname, mime=True)

print(filetype("image.png"))
