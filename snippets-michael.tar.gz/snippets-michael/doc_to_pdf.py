# 6011115
# .doc to pdf using python
import sys
import os
import platform

def doc_to_pdf(in_file, out_file):
    p = platform.platform()
    if not p.startswith('Win'):
        print('windows platform only')
        sys.exit(-1)

    import comtypes.client

    wdFormatPDF = 17

    word = comtypes.client.CreateObject('Word.Application')
    doc = word.Documents.Open(in_file)
    doc.SaveAs(out_file, FileFormat=wdFormatPDF)
    doc.Close()
    word.Quit()
# Test
doc_to_pdf('test.doc', 'test.pdf')
