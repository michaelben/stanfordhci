# 16766643
# Convert Date String to Day of Week
import datetime
def get_day_of_week_from_datetime(date, format):
    return datetime.datetime.strptime(date, format).strftime('%A')
# Test
print(get_day_of_week_from_datetime('January 11, 2010', '%B %d, %Y'))
