# 6169324
# partition string in python and get value of last segment after colon
def partition_string(s):
    return s.rpartition(':')[2]
# Test
print(partition_string('client:user:username:type:1234567'))
