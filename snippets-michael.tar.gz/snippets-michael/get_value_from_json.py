# 5458873
# Get the value  of json data
import json
def get_value_from_json(jsondata, key):
    parsed_data = json.loads(jsondata)
    return parsed_data[key]
# Test
print(get_value_from_json('''{"title":"sss",
    "body":"wwww：aaa&nbsp;&nbsp;&nbsp;<a href='#' onclick='logout()' >fff</a>",
    "data":{"status":0,"userName":"www","userId":"433"}}''', 'title'))
