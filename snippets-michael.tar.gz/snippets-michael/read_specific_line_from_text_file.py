# 2081836
# Read a specific line of a text file in Python
from io import StringIO

def read_specific_line_from_text_file(fp, linenum):
    for i, line in enumerate(fp):
        if i == linenum - 1:
            print(line)
        elif i > linenum - 1:
            break
    fp.close()
# Test
read_specific_line_from_text_file(StringIO('''\
        This is the first line
        This is the second line
        This is the third line
        This is the fourth line'''), 3)

