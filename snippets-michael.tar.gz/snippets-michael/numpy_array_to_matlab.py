# 10997254
# Converting Numpy arrays to Matlab and vice versa
import numpy as np
import scipy.io
def numpy_array_to_matlab(fname, x, y):
    scipy.io.savemat(fname, dict(x=x, y=y))
# Test
numpy_array_to_matlab('test.mat', np.linspace(0, 2 * np.pi, 100),  np.cos(np.linspace(0, 2 * np.pi, 100)))
