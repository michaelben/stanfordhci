# 2173087
# Create nested lists in python
import numpy as np
def create_nested_lists(rows, cols, depths):
    return np.zeros((rows, cols, depths))
# Test
print(create_nested_lists(3, 3, 3))
