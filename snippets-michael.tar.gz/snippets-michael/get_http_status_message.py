# 2723715
# Get HTTP status message in (py)curl
import pycurl
from io import BytesIO
import re

def get_http_status_message(url):
    curl = pycurl.Curl()

    buff = BytesIO()
    hdr = BytesIO()

    curl.setopt(pycurl.URL, url)
    curl.setopt(pycurl.WRITEFUNCTION, buff.write)
    curl.setopt(pycurl.HEADERFUNCTION, hdr.write)
    curl.perform()

    print("status code: %s" % curl.getinfo(pycurl.HTTP_CODE))

    status_line = hdr.getvalue().splitlines()[0]
    m = re.match(r'HTTP\/\S*\s*\d+\s*(.*?)\s*$', status_line.decode())
    if m:
        status_message = m.groups(1)
    else:
        status_message = ''

    print("status message: %s" % status_message)
# Test
get_http_status_message('http://www.wikipedia.org')
