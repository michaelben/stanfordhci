# 9419451
# 3D Contour plot from data using Mayavi / Python
from scipy.interpolate import griddata
import numpy as np

def 3d_contour_plot_mayavi():
    # Create some test data, 3D gaussian, 200 points
    dx, pts = 2, 100j

    N = 500
    R = np.random.random((N,3))*2*dx - dx
    V = np.exp(-( (R**2).sum(axis=1)) )

    # Create the grid to interpolate on
    X,Y,Z = np.mgrid[-dx:dx:pts, -dx:dx:pts, -dx:dx:pts]

    # Interpolate the data
    F = griddata(R, V, (X,Y,Z))

    try:
        from mayavi.mlab import *
    except:
        print('mayavi module is needed')
        sys.exit(-1)

    contour3d(F,contours=8,opacity=.2 )
# Test
3d_contour_plot_mayavi()
