# 18062135
# Combining two Series into a DataFrame in pandas

import pandas as pd

def pandas_concat(series):
    return pd.concat(series, axis=1).reset_index()

print(pandas_concat([pd.Series([1, 2], index=['A', 'B'], name='s1'), pd.Series([3, 4], index=['A', 'B'], name='s2')]))
