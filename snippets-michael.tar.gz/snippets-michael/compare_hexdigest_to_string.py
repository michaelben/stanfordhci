# 3583265
# Compare result from hexdigest() to a string
import hashlib
def compare_hexdigest_to_string(s, result):
    return hashlib.md5(s.encode("utf8")).hexdigest() == result
# Test
print(compare_hexdigest_to_string('foo', 'acbd18db4cc2f85cedef654fccc4a4d8'))
