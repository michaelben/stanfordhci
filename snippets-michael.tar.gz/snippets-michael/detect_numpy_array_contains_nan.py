# 911871
# Detect if a NumPy array contains at least one non-numeric value
import numpy
def detect_numpy_array_contains_nan(arr):
    return numpy.isnan(arr).any()
# Test
print(detect_numpy_array_contains_nan(numpy.arange(10)))
