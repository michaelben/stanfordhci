# 17610698
# Python string.format() percentage to one decimal place
from math import floor

def floored_percentage(val, digits):
    val *= 10 ** (digits + 2)
    return '{1:.{0}f}%'.format(digits, floor(val) / 10 ** digits)

# Test
print(floored_percentage(0.995, 1))
