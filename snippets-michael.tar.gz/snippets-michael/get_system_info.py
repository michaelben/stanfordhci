# 3103178
# Get the system info
import platform
def get_system_info():
    print(platform.machine())
    print(platform.version())
    print(platform.platform())
    print(platform.uname())
    print(platform.system())
    print(platform.processor())
# Test
get_system_info()
