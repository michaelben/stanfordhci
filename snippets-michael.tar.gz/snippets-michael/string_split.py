# 29887425
# string split in python
def string_split(content):
    for i in content:
        name,*scores=i.split()
        print(name, scores)
# Test
string_split(['asd 12 23 4', 'sdf 234 4', 'hj 54 2 3'])
