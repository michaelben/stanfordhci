# 7159607
# List directories with a specified depth in Python
import glob, os, os.path
def get_directories_with_specified_depth(path, depth):
    os.chdir(path)
    pattern = os.path.sep.join(list('*'*depth))
    filesDepth = glob.glob(pattern)
    dirsDepth = filter(lambda f: os.path.isdir(f), filesDepth)
    return list(dirsDepth)
# Test
print(get_directories_with_specified_depth('..', 3))
