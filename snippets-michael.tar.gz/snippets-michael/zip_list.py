# 11703064
# Add two lists' elements into one list
def zip_list(list1, list2):
    return [a + b for a, b in zip(list1, list2)]
# Test
print(zip_list(['good', 'bad', 'tall', 'big'], ['boy', 'girl', 'guy', 'man']))
