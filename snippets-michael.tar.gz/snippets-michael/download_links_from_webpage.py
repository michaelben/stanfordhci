# 6649001
# Download all the links(related documents) on a webpage using Python
from time import sleep
import sys

def download_links_from_webpage():
    try:
        import mechanize
    except:
        print('mechanize module needed')
        sys.exit(-1)

    #Make a Browser (think of this as chrome or firefox etc)
    br = mechanize.Browser()

    # Open your site
    br.open('http://pypi.python.org/pypi/xlwt')

    filetypes=[".zip",".exe",".tar.gz"] #you will need to do some kind of pattern matching on your files
    myfiles=[]
    for l in br.links(): #you can also iterate through br.forms() to print forms on the page!
        for t in filetypes:
            if t in str(l): #check if this link has the file extension we want (you may choose to use reg expressions or something)
                myfiles.append(l)

    def downloadlink(l):
        f=open(l.text,"w") #perhaps you should open in a better way & ensure that file doesn't already exist.
        br.click_link(l)
        #f.write(br.response().read())
        print(br.response().read()) #debug
        print(l.text," has been downloaded")
        #br.back()

    for l in myfiles:
        sleep(1) #throttle so you dont hammer the site
        downloadlink(l)
# Test
download_links_from_webpage()
