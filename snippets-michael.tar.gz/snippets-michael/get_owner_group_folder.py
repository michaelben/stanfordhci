# 927866
# Get the owner and group of a folder with Python on a Linux machine?
import grp
import pwd
import os, sys
import platform

def get_owner_group_folder(folder):
    p = platform.platform()
    if not p.startswith('Linux'):
        print('not linux platform')
        sys.exit(-1)

    stat_info = os.stat(folder)
    uid = stat_info.st_uid
    gid = stat_info.st_gid
    print(uid, gid)

    user = pwd.getpwuid(uid)[0]
    group = grp.getgrgid(gid)[0]
    print(user, group)
# Test
get_owner_group_folder('.')
