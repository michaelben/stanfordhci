# 6548837
# Get an event callback when a Tkinter Entry widget is modified
from tkinter import *

def set_modified_callback_for_tkinter_entry_widget():
    def callback(sv):
        print(sv.get())

    root = Tk()
    sv = StringVar()
    sv.trace("w", lambda name, index, mode, sv=sv: callback(sv))
    e = Entry(root, textvariable=sv)
    e.pack()
    root.mainloop()
# Test
set_modified_callback_for_tkinter_entry_widget()
