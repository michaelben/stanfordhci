# 6692908
# Formatting messages to send to socket.io node.js server from python client
def sockio_client_demo():
    def handshake(host, port):
        u = urlopen("http://%s:%d/socket.io/1/" % (host, port))
        if u.getcode() == 200:
            response = u.readline()
            (sid, hbtimeout, ctimeout, supported) = response.split(":")
            supportedlist = supported.split(",")
            if "websocket" in supportedlist:
                return (sid, hbtimeout, ctimeout)
            else:
                raise TransportException()
        else:
            raise InvalidResponseException()

    try:
        (sid, hbtimeout, ctimeout) = handshake(HOSTNAME, PORT) #handshaking according to socket.io spec.
    except Exception as e:
        print(e)
        sys.exit(1)
    ws = websocket.create_connection("ws://%s:%d/socket.io/1/websocket/%s" % (HOSTNAME, PORT, sid))
    print(ws.recv())
    ws.send('2::')
    ws.send('5:1::{"name":"newimg", "args":"bla"}')
    print(ws.recv())
    print("Closing connection")
    ws.close()
# Test
