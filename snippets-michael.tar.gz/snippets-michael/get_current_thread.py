# 17707775
# Get thread ID or name
from threading import Thread, current_thread
def get_current_thread():
    print(current_thread())
# Test
get_current_thread()
