# 20205455
# Correctly parse UTF-8 encoded HTML to Unicode strings with BeautifulSoup
import urllib.request
from bs4 import BeautifulSoup

def parse_utf8_html_bs():
    # Fetch URL
    url = 'http://www.voxnow.de/'
    request = urllib.request.Request(url)
    request.add_header('Accept-Encoding', 'utf-8')

    # Response has UTF-8 charset header,
    # and HTML body which is UTF-8 encoded
    response = urllib.request.urlopen(request)

    # Parse with BeautifulSoup
    soup = BeautifulSoup(response.read().decode('utf-8', 'ignore'), 'lxml')

    # Print title attribute of a <div> which uses umlauts (e.g. können)
    print(repr(soup))
# Test
parse_utf8_html_bs()
