# 3640359
# Regular Expressions: Search in list
import re
def list_filter(r, myList):
    return list(filter(r.match, myList))
# Test
print(list_filter(re.compile('^.*?(\d+).*$'), ['adf', 'a234a', '234', 'ssssf234']))
