# 3345030
# Splitting a string separated by rn into a list of lines?
def string_splitlines(s):
    return s.splitlines()
# Test
print(string_splitlines("foo\r\nbar\r\nfoo\n\rbar"))
