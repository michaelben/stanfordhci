# 14016247
# Find integer index of rows with NaN in pandas

import numpy as np
import pandas as pd

def find_NaN_index_pandas(df, col):
    index = df[col].index[df[col].apply(np.isnan)]
    df_index = df.index.values.tolist()
    return [df_index.index(i) for i in index]

print(find_NaN_index_pandas(pd.DataFrame({
'a':[1, 2, 3, 4, 5, 6],
'b':[1, 2, float('nan'), 4, float('nan'), 6]
}), 'b'))
