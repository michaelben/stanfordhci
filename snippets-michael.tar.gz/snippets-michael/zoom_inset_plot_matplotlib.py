# 13583153
# Zoomed a portion of image and insert in the same plot in matplotlib
from numpy import *
import matplotlib.pyplot as plt
def zoom_inset_plot_matplotlib(datafile):
    data = loadtxt(datafile, skiprows=1)
    fig1 = plt.figure()
    ax1 = fig1.add_subplot(111)
    ax1.semilogx(data[:,1],data[:,2])

    ax2 = plt.axes([.65, .6, .2, .2], axisbg='y')
    ax2.semilogx(data[3:8,1],data[3:8,2])
    plt.setp(ax2, xticks=[], yticks=[])

    plt.show()
# Test
