# 4912972
# Check (in runtime) if a given class is a subclass of another given class

def is_subclass(sub, cls):
    return issubclass(sub, cls)

print(is_subclass(int, object))
