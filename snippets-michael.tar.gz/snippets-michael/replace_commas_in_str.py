# 10610402
# Replace commas in a string
def replace_commas_in_str(s, replacement):
    return s.replace(',', replacement)
# Test
print(replace_commas_in_str("123,asd,wer", ''))
