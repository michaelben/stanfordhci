# 17933282
# Read a csv file with strings containing commas
import pandas as pd
from io import StringIO
def read_csv_item_contain_commas(csv_file_fd):
    return pd.read_csv(csv_file_fd, quotechar='"', skipinitialspace=True)
# Test
print(read_csv_item_contain_commas(StringIO('''\
        year, city, value
        2012, "Louisville KY", 3.5
        2011, "Lexington, KY", 4.0''')))
