# 1864701
# Convert UTF-8 octets to unicode code points
def get_code_point_from_utf8_bytes(u):
    return hex(ord(u.decode('utf-8')))
# Test
print(get_code_point_from_utf8_bytes(b'\xc5\x81'))
