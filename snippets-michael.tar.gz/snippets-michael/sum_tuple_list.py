# 14180866
# sum each value in a list of tuples
def sum_tuple_list():
    l = [(1, 2), (3, 4), (5, 6), (7, 8), (9, 0)]
    print([sum(x) for x in zip(*l)])
    print(list(map(sum, zip(*l))))
# Test
sum_tuple_list()
