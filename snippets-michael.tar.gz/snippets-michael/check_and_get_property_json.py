# 11748234
# Check whether the JSON object property exists & print it as unicode decoded

import simplejson

def check_and_get_property_json(info):
    data = simplejson.loads(info)
    for post in data['data']:
        if post.get('caption'):
            print(post['caption'].get('text', 0))

check_and_get_property_json('''
{
   "meta":{
      "code":200
   },
   "data":[
      {
         "attribution":null,
         "tags":[
            "usausausa",
            "olympics"
         ],
         "type":"image",
         "location":{
            "latitude":37.785929,
            "name":"Aquatech Swim School",
            "longitude":-122.278718,
            "id":16343815
         },
         "filter":"Valencia",
         "created_time":"1343765260",
         "caption":{
            "created_time":"1343765325",
            "text":"Part of my job to watch swimming. #olympics #USAUSAUSA",
            "id":"247843973390332239"
         },
         "user_has_liked":false,
         "id":"247843429330383145_4672491"
      }
   ]
}
''')
