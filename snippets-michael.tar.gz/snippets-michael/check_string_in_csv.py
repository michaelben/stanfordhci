# 17308872
# Check whether string is in CSV
import csv
from io import StringIO
def check_string_in_csv(csvf, s):
    reader = csv.reader(csvf, delimiter=',') # good point by @paco
    for row in reader:
        for field in row:
            if field == s:
                return True
    return False
# Test
print(check_string_in_csv(StringIO('''\
1,234,asf
2,234,3sdf
3,344,bbb'''), 'bbb'))
