# 243836
# How to copy all properties of an object to another object, in Python?
def copy_object_properties(oobj, nobj):
    nobj.__dict__.update(oobj.__dict__)
# Test
