# 7362130
# Getting video dimension from ffmpeg -i
import subprocess
import shlex
import shutil
import json
import sys

# function to find the resolution of the input video file
def find_video_resolution(video):
    p = shutil.which('ffprobe')
    if not p:
        print('ffprobe needed')
        sys.exit(-1)

    cmd = "ffprobe -v quiet -print_format json -show_streams"
    args = shlex.split(cmd)
    args.append(video)
    # run the ffprobe process, decode stdout into utf-8 & convert to JSON
    ffprobeOutput = subprocess.check_output(args).decode('utf-8')
    ffprobeOutput = json.loads(ffprobeOutput)

    # find height and width
    height = ffprobeOutput['streams'][0]['height']
    width = ffprobeOutput['streams'][0]['width']

    return height, width
# Test
print(find_video_resolution('test.mp4'))
