# 1501651
# Log output of multiprocessing.Process
from multiprocessing import Process
import os
import sys

def log_output_multiprocessing_process():
    def info(title):
        print(title)
        print('module name:', __name__)
        print('parent process:', os.getppid())
        print('process id:', os.getpid())
    def f(name):
        sys.stdout = open(str(os.getpid()) + ".out", "w")
        info('function f')
        print('hello', name)

    p = Process(target=f, args=('bob',))
    p.start()
    q = Process(target=f, args=('fred',))
    q.start()
    p.join()
    q.join()
# Test
log_output_multiprocessing_process()
