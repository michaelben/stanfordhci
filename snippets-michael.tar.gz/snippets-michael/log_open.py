# 3370540
# List all currently open file handles
def log_open( open_file_handles, *args, **kwargs ):
    f = open( *args, **kwargs )
    open_file_handles.append(f)
    return f
# Test
open_file_handles = []
log_open(open_file_handles, 'out.txt', 'r')
print(open_file_handles)
