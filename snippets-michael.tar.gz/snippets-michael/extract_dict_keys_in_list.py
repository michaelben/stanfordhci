# 5318747
# Extract dictionary keys/values within a list

import urllib.request
import json

def extract_dict_keys_in_list(myList, key):
	return [trend[key] for trend in myList]

print(extract_dict_keys_in_list([{'name': 'apple'}, {'name': 'security'}, {'name':'terror'}], 'name'))
