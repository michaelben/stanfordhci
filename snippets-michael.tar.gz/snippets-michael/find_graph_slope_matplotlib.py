# 2244386
# Python: Find the slope of a graph drawn using matplotlib
import matplotlib.pyplot as plt
import numpy as np

def find_graph_slope_matplotlib():
    length = np.random.random(10)
    length.sort()
    time = np.random.random(10)
    time.sort()
    slope, intercept = np.polyfit(np.log(length), np.log(time), 1)
    print(slope)
    plt.loglog(length, time, '--')
    plt.show()
# Test
find_graph_slope_matplotlib()
