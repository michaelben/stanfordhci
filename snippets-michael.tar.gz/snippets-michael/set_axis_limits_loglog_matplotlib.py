# 11370783
# Set axis limits in loglog plot with matplotlib
import matplotlib.pyplot as plt
def set_axis_limits_loglog_matplotlib():
    x = [2**i for i in range(4,14)]
    y = [i**2 for i in x]
    plt.loglog(x,y,'ro',basex=2,basey=2)
    plt.xlim([1, 2**14]) # Zero can not be plotted on a loglog graph
    plt.show()
# Test
set_axis_limits_loglog_matplotlib()
