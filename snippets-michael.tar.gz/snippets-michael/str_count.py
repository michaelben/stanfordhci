# 1666700
# Count the number of times something occurs inside a certain string
def str_count(s, sub):
    return s.count(sub)
# Test
print(str_count("The big brown fox is brown", "brown"))
