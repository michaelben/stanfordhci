# 21285684
# Read numbers in text file
from io import StringIO

def read_int_from_text_file(f, cols):
    a = []
    for i in range(cols):
        a.append([])
    for line in f:
        for i, value in enumerate(line.split()):
            a[i].append(int(value))
    return a
# Test
print(read_int_from_text_file(StringIO('''
1 2 3 4
5 6 7 8
9 10 11 12
13 14 15 15
'''), 4))
