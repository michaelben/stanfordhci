# 10311323
# Concatenate or print list elements with a trailing comma in Python
def cat_add_trailing_comma(s):
    return ', '.join(s) + ','
# Test
print(cat_add_trailing_comma(['1', '2', '3', '4']))
