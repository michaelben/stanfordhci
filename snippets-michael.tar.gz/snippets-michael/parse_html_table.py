# 9919493
# parsing HTML table using python - HTMLparser or lxml
from lxml.html import parse
def parse_html_table():
    page = parse("test.html")
    rows = page.xpath("body/table")[0].findall("tr")
    data = list()
    for row in rows:
        data.append([c.text for c in row.getchildren()])
    for row in data[4:]:
        print(row)
# Test
parse_html_table()
