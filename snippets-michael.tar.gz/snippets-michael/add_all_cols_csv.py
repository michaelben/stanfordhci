# 2457193
# Looping through columns in a .csv files in Python
import csv
from io import StringIO

def add_all_cols_csv(csv_file):
    total = 0
    for row in csv.reader(csv_file, delimiter=','):
        for col in row:
            total += int(col)

    return total    # prints 10
# Test
print(add_all_cols_csv(StringIO("1,2,3,4")))
