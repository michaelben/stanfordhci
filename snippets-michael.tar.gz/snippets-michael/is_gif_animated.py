# 1412529
# programmatically check whether a GIF image is animated
from PIL import Image
def is_gif_animated(img):
    gif = Image.open(img)
    try:
        gif.seek(1)
    except EOFError:
        gif.seek(0)
        return False
    else:
        gif.seek(0)
        return True
# Test
print(is_gif_animated('robin.gif'))
