# 3327775
# Delay the execution of statements in Python
import time
def delay_execution(interval):
    print('begin')
    time.sleep(interval)
    print('end')
# Test
delay_execution(2)
