# 14047979
# Executing Python script in PHP and exchanging data between the two

import json

def send_data_to_external(result):
    return (json.dumps(result))

print(send_data_to_external({'status': 'Yes!'}))
