# 1015142
# Running Python code contained in a string
def run_python_code_in_string(code, scope):
    exec(code, scope)
# Test
run_python_code_in_string("print('hello')", {'os':None})
