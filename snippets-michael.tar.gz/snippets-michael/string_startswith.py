# 20461847
# str.startswith with a list of strings to test for
def string_startswith(s, startswith):
    return s.startswith(startswith)
# Test
print(string_startswith('catalogasdf', ("js", "catalog", "script", "katalog")))
