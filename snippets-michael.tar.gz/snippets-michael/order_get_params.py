# 8802945
# python-requests: order get parameters
import requests
def order_get_params(url, params):
    return requests.get(url, params=params)
# Test
print(order_get_params("http://httpbin.org/get", (('key1', 'value1'), ('key2', 'value2'), ('key3', 'value3'))).json()['url'])
