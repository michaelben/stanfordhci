# 7567642
# Where to put a configuration file in Python?
import os
import os.path

def get_config_from_different_source(conf='myproject.conf'):
    for loc in os.curdir, os.path.expanduser("~"), "/etc/myproject", os.environ.get("MYPROJECT_CONF"):
        if loc:
            try: 
                with open(os.path.join(loc,conf)) as source:
                    return source
            except IOError:
                pass
# Test
get_config_from_different_source()
