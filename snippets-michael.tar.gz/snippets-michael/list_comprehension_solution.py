# 4280691
# list.reverse does not return list
def list_comprehension_solution(formation):
    fCamel = 'F'
    bCamel = 'B'
    gap = ' '
    return len([k for k in formation[formation.index(bCamel)+1:] if k == fCamel]) == 0
# Test
print(list_comprehension_solution(['F','F','B','B','F']))
print(list_comprehension_solution(['F','F','B','B','B']))
print(list_comprehension_solution(['F','F','B','F','F','B','B']))
