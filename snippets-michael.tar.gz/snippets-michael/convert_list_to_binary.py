# 537077
# Python, Sqlite3 - How to convert a list to a BLOB cell
import array
def convert_list_to_binary(data, datatype):
    return array.array(datatype, data)
# Test
print(convert_list_to_binary([ 0, 1, 2, 3, 4, 5 ], 'B').tostring())
