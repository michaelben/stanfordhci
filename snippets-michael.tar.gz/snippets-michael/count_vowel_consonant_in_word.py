# 7736211
# Counting the amount of vowels or consonants in a user input word
def count_vowel_consonant_in_word(word):
    vowels = list("aeiouy")
    consonants = list("bcdfghjklmnpqrstvexz")

    number_of_consonants = sum(word.count(c) for c in consonants)
    number_of_vowels = sum(word.count(c) for c in vowels)

    return number_of_consonants, number_of_vowels
# Test
print(count_vowel_consonant_in_word('woeruskhkshfaw'))
