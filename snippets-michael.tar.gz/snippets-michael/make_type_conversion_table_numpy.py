# 9452775
# Converting numpy dtypes to native python types

import numpy as np

def make_type_conversion_table_numpy():
    for name in dir(np):
        obj = getattr(np, name)
        if hasattr(obj, 'dtype'):
            try:
                npn = obj(0)
                nat = npn.item()
                print('%s (%r) -> %s'%(name, npn.dtype.char, type(nat)))
            except:
                pass

make_type_conversion_table_numpy()
