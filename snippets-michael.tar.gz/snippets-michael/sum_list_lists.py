# 13783315
# Sum of list of lists; returns sum list
def sum_list_lists(l):
    return [sum(i) for i in zip(*l)]
# Test
print(sum_list_lists([[3,7,2],[1,4,5],[9,8,7]]))
