# 21151174
# Python: if list contains string print all the indexes / elements in the list that contain it
def find_string_indices_in_list(mylist, string):
    for s in mylist:
        if string in str(s):
            print(s)
# Test
find_string_indices_in_list(['A second goldfish is nice and all', 3456, 'test nice'], 'nice')
