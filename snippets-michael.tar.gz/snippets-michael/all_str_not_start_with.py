# 6763414
# The easiest way to get all strings that do not start with a character
def all_str_not_start_with(x, ch):
    for line in (line for line in x if not line.startswith(ch)):
        print(line)
# Test
all_str_not_start_with(['asd', '?asf', 'uwou'], '?')
