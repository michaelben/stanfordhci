# 5666056
# matplotlib - extracting data from contour lines
import matplotlib.pyplot as plt
def extract_data_from_contour_lines():
    # make contour_lines
    x = [1,2,3,4]
    y = [1,2,3,4]
    m = [[15,14,13,12],[14,12,10,8],[13,10,7,4],[12,8,4,0]]
    cs = plt.contour(x,y,m, [9.5])

    # get path
    path = cs.collections[0].get_paths()[0]

    def get_points_from_path(path):
        v = path.vertices
        x = v[:,0]
        y = v[:,1]
        return x, y

    return get_points_from_path(path)
# Test
print(extract_data_from_contour_lines())
