# 6727875
# Hex string to signed int in Python 3.2?
def hex_string_to_signed_int(h):
    x = int(h,16)
    if x > 0x7FFFFFFF:
        x -= 0x100000000
    return x
# Test
print(hex_string_to_signed_int('9DA92DAB'))
