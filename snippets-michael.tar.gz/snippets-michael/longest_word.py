# 1192881
# How to find the longest word with python?
def longest_word(s):
    return max(s.split(), key=len)
# Test
print(longest_word("a aa aaa aa"))
