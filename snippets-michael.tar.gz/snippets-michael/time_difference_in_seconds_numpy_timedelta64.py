# 20738357
# Time difference in seconds from numpy.timedelta64
import numpy as np
def time_difference_in_seconds_numpy_timedelta64(time1, time2):
    dt = np.datetime64(time1) - np.datetime64(time2)
    return dt.item().total_seconds()
# Test
print(time_difference_in_seconds_numpy_timedelta64('2012-10-05 04:45:18', '2012-10-05 04:44:13'))
