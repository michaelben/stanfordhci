# 7794087
# Running javascript in Selenium using Python

from selenium import webdriver

def call_javascript_in_selenium(url, js_code):
    wd = webdriver.Firefox()
    wd.get(url)
    return wd.execute_script(js_code)

print(call_javascript_in_selenium('http://michaelben.github.io/product-catalog-demo/test/formexample.html', 'return foobar()'))
