# 14177582
# number/numbers to list by using input()
def get_numbers():
    return [int(n) for n in input('Number(s): ').split(',') if n.isdigit()]
# Test
print(get_numbers())
