from xml.etree import ElementTree
import urllib.request
import urllib.parse
def consume_xml_response_demo():
    """Find a book in the collection specified"""

    search_args = [('access_key', api_key),]
    if not is_valid_collection(kwargs['collection']):
        return None
    kwargs.pop('collection')
    for key in kwargs:
        # Only the first keword is honored
        if kwargs[key]:
            search_args.append(('index1', key))
            search_args.append(('value1', kwargs[key]))
            break

    url = urllib.parse.urljoin(api_url, '%s.xml' % 'books')
    data = urllib.parse.urlencode(search_args)
    req = urllib.request.urlopen(url, data)
    rdata = []
    chunk = 'xx'
    while chunk:
        chunk = req.read()
        if chunk:
            rdata.append(chunk)
    tree = ElementTree.fromstring(''.join(rdata))
    results = []
    for i, elem in enumerate(tree.getiterator('BookData')):
        results.append(
               {'isbn': elem.get('isbn'),
                'isbn13': elem.get('isbn13'),
                'title': elem.find('Title').text,
                'author': elem.find('AuthorsText').text,
                'publisher': elem.find('PublisherText').text,}
            )
    return results
# Test
