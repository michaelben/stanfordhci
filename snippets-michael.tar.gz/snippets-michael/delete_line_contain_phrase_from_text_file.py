# 17747522
# Delete a line from a text file using the line number in python
import fileinput

def delete_line_contain_phrase_from_text_file(filename, phrase):
    for line in fileinput.input(filename, inplace=True):
        if phrase in line:
            continue
        print(line, end='')
# Test
delete_line_contain_phrase_from_text_file('test.txt.1', 'barked')
