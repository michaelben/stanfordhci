# 3241804
# Modify python script to run on every file in a directory
import os
def run_folder(folder, func):
    for f in os.listdir(folder):
        func(f)
# Test
run_folder('.', print)
