# 3453177
# Convert Python datetime to rfc 2822
import datetime
import time
from email import utils
def convert_python_datetime_to_rfc_2822():
    nowdt = datetime.datetime.now()
    nowtuple = nowdt.timetuple()
    nowtimestamp = time.mktime(nowtuple)
    return utils.formatdate(nowtimestamp)
# Test
print(convert_python_datetime_to_rfc_2822())
