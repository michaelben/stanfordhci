# 21958534
# Setting the window to a fixed size with Tkinter

import tkinter as tk

def get_fixed_window_Tkinter():
    root = tk.Tk()
    root.resizable(width=FALSE, height=FALSE)
    root.mainloop()

get_fixed_window_Tkinter()
