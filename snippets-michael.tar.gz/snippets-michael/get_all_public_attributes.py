# 8935462
# Iterate over an object's public attributes
import sys
def get_all_public_attributes(obj):
    public_props = (name for name in dir(obj) if not name.startswith('_'))
    for name in public_props:
        print(name)
# Test
get_all_public_attributes(sys)
