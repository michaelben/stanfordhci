# 3918433
# Make sure a file exists or can be created before writing to it
def write_to_file(fname, data):
    with open(fname, 'w') as f:
        f.write(data)
# Test
write_to_file('some_file_that_might_not_exist.txt', 'file data')
