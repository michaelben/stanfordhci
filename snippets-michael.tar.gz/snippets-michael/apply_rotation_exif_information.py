# 1606587
# Resize and apply rotation EXIF information to the file
import sys

def apply_rotation_exif_information(imgfname):
    try:
        import pyexiv2
    except:
        print("To use this program, you need to install pyexiv2 - http://tilloy.net/dev/pyexiv2/")
        sys.exit(1)

    image = pyexiv2.Image(imgfname)
    image.readMetadata()

    image['Exif.Image.Orientation'] = 6
    image.writeMetadata()
# Test
