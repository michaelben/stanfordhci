# 8199398
# Extracting only characters from a string in Python
import re
def extract_words_from_string(s):
    return " ".join(re.findall("[a-zA-Z]+", s))
# Test
print(extract_words_from_string("{('players',): 24, ('year',): 28, ('money',): 19, ('ipod',): 36, ('case',): 23, ('mini',): 46}"))
