# 2709818
# Fastest Way to generate 1,000,000+ random numbers in python
import numpy as np
def rand_row_doubles(row_limits, num):
    ncols = len(row_limits)
    x = np.random.random((num, ncols))
    x *= row_limits                  
    return x
# Test
print(rand_row_doubles(np.arange(7) + 1, 1000000))
