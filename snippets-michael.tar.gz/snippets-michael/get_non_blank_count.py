# 10673560
# Count number of lines in a txt file but exclude blank lines

def get_non_blank_count(file):
    non_blank_count = 0

    with open(file) as infp:
        for line in infp:
           if line.strip():
              non_blank_count += 1

    return non_blank_count

print(get_non_blank_count('get_non_blank_count.py'))
