# 4613465
# Using python to write mysql query to csv, need to show field names
import sys
import csv

def write_mysql_query_to_csv():
    try:
        import pymysql.cursors
    except:
        print('need mysql module installed')
        sys.exit(-1)

    dbServer='localhost'
    dbPass='supersecretpassword'
    dbSchema='dbTest'
    dbUser='root'

    dbQuery='SELECT * FROM pbTest.Orders;'

    db=pymysql.connect(host=dbServer,user=dbUser,passwd=dbPass,
                       db='dbTest',
                       charset='utf8mb4',
                       cursorclass=pymysql.cursors.DictCursor)
    try:
        with db.cursor() as cur:
            cur.execute(dbQuery)
            result=cur.fetchall()
    finally:
        db.close()

    c = csv.writer(open("temp0415.csv","wb"))
    c.writerows(result)
# Test
