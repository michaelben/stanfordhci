# 25748683
# Python - Pandas sum dataframe rows for given columns
import pandas as pd
def sum_dataframe_pandas(df):
    df['e'] = df.sum(axis=1)
    return df
# Test
print(sum_dataframe_pandas(pd.DataFrame({'a': [1,2,3], 'b': [2,3,4], 'c':['dd','ee','ff'], 'd':[5,9,1]})))
