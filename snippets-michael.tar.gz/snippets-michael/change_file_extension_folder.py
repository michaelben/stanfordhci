# 16736080
# Change the file extension for files in a folder in Python
import os
def change_file_extension_folder(folder, oldext, newext):
    for filename in os.listdir(folder):
        infilename = os.path.join(folder, filename)
        if not os.path.isfile(infilename): continue
        newname = infilename.replace(oldext, newext)
        os.rename(infilename, newname)
# Test
change_file_extension_folder('test', '.ext', '.txt')
