# 3575165
# Unset a linux environment variable in python
import os
import sys
def unset_environment_variable(env):
    try:
        del os.environ[env]
    except KeyError:
        print('no such variable')
        sys.exit(-1)
# Test
unset_environment_variable('MYVAR')
