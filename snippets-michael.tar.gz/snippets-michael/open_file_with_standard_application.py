# 1679798
# Open a file with the standard application
import sys
import os
import subprocess
import webbrowser
def open_file_with_standard_application(file):
    if sys.platform.startswith('linux'):
        subprocess.call(["xdg-open", file])
    elif sys.platform.startswith('win'):
        os.startfile(file)
    elif sys.platform.startswith('darwin'):
        webbrowser.open(file)
    else:
        sys.exit(-1)
# Test
open_file_with_standard_application('open_file_with_standard_application.py')
