# 6317500
# Splice a string: replace a part of string with another string with possibly different length

def splice(a,b,c,d=None):
    if isinstance(b,(list,tuple)):
        return a[:b[0]]+c+a[b[1]:]
    return a[:b]+d+a[c:]

print(splice('hello world',0,5,'pizza'))
print(splice('hello world',(0,5),'pizza'))
