# 17477979
# Dropping infinite values from dataframes in pandas
import pandas as pd
import numpy as np
def drop_infinite_values_from_dataframes_pandas(df):
    return df.replace([np.inf, -np.inf], np.nan).dropna(subset=["col1", "col2"], how="all")
# Test
print(drop_infinite_values_from_dataframes_pandas(pd.DataFrame({"col1":[1, 2, np.inf, -np.inf], "col2":[3, 4, np.inf, -np.inf]})))
