# 352837
# Add file extensions based on file type on Linux/Unix
import mimetypes
import os
import sys
from subprocess import Popen, PIPE

def add_file_ext_by_file_type_linux(folder):
    for filename in (f.rstrip() for f in os.listdir(folder)):
        output, _ = Popen(['file', '-bi', filename], stdout=PIPE).communicate()
        mime = output.decode().split(';', 1)[0].lower().strip()
        ext = mimetypes.guess_extension(mime, strict=False)
        if ext is None:
            ext = os.path.extsep + 'undefined'
        filename_ext = filename + ext
        print(filename_ext)
# Test
add_file_ext_by_file_type_linux('.')
