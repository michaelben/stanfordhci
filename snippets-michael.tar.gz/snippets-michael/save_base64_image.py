# 2323128
# Convert string in base64 to image and save on filesystem

from base64 import decodestring

def save_base64_image(image_file=None, imagestr=None):
    with open(image_file,"wb") as f:
        f.write(decodestring(imagestr.encode()))

save_base64_image(image_file="image.png", imagestr="iVBORw0KGgoAAAANSUhEUgAAABAAAAAQAQMAAAAlPW0iAAAABlBMVEUAAAD///+l2Z/dAAAAM0lEQVR4nGP4/5/h/1+G/58ZDrAz3D/McH8yw83NDDeNGe4Ug9C9zwz3gVLMDA/A6P9/AFGGFyjOXZtQAAAAAElFTkSuQmCC")
