# 9805451
# How to find names of all collections using PyMongo?
import pymongo
from pymongo import database

def get_names_all_collections_pymongo(db):
    return db.collection_names()
# Test
