# 6826495
# Convert this particular json string into a python dictionary
import json
def json_to_dict():
    d = json.loads('[{"name":"sam"}]')
    print(d[0])
# Test
json_to_dict()
