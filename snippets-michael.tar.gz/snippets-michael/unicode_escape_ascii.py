# 267436
# Treat an ASCII string as unicode and unescape the escaped characters in it in python
def unicode_escape_ascii():
    s = b'\u003cfoo/\u003e'
    s_unicode_escape = s.decode( 'unicode-escape' )
    s_ascii = s.decode( 'unicode-escape' ).encode( 'ascii' )
    print(s)
    print(s_unicode_escape)
    print(s_ascii)
# Test
unicode_escape_ascii()
