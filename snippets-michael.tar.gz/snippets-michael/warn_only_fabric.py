# 10207600
# Make Fabric continue running the next command after getting the exit status: 1
from fabric.api import local, settings, abort
from fabric.contrib.console import confirm

def warn_only_fabric():
    with settings(warn_only=True):
        result = local('./manage.py test my_app', capture=True)
    if result.failed and not confirm("Tests failed. Continue anyway?"):
        abort("Aborting at user request.")

# Test
warn_only_fabric()
