# 2548000
# Sorting a dictionary having keys as string of numbers in python
def dict_sort_key_compare(a):
    MAX_DIGITS = 10
    def _keyify(x):
        try:
            xi = int(x)
        except ValueError:
            return 'S{0}'.format(x)
        else:
            return 'I{0:0{1}}'.format(xi, MAX_DIGITS)

    for k in sorted(a, key=_keyify):
        print(k, a[k])
# Test
dict_sort_key_compare({'100':12,'6':5,'88':3,'test':34, '67':7,'1':64 })
