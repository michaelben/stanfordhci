# 9168340
# Python: Using a dictionary to select function to execute
def execute_function_by_key(key):
    def ExecP1():
        pass
    def ExecP2():
        pass
    def ExecP3():
        pass
    def ExecPn():
        pass 
    locals()['Exec' + key]()
# Test
execute_function_by_key('P1')
