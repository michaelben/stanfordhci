# 8180014
# How to subclass Python list without type problems?
def custom_list_demo():
    class CustomList(list):
        def __getslice__(self,i,j):
            return CustomList(list.__getslice__(self, i, j))
        def __add__(self,other):
            return CustomList(list.__add__(self,other))
        def __mul__(self,other):
            return CustomList(list.__mul__(self,other))
        def __getitem__(self, item):
            result = list.__getitem__(self, item)
            try:
                return CustomList(result)
            except TypeError:
                return result
    l = CustomList((1,2,3))
    print(l)
    l.append(4)                       
    print(l)
    l[0] = -1
    print(l)
    l[0:2] = CustomList((10,11))
    print(l)
    l3 = l + CustomList((4,5,6))
    print(l3)
    l4 = 3*l
    print(l4)
    l5 = l[0:2]
    print(l5)
    l6 = l[0:2:2]
    print(l6)
# Test
custom_list_demo()
