# 8084260
# Printing a file to stdout

def print_file(fname):
    with open(fname, 'r') as fin:
        print(fin.read())

print_file("print_file.py")
