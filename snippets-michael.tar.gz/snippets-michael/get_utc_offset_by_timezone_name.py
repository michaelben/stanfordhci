# 5537876
# get UTC offset from time zone name in python
import datetime, pytz
def get_utc_offset_by_timezone_name(tz_name, date_time):
    '''get utc offset by tz name and datetime.
    utc offset is different based on DST on different date time.
    '''
    return pytz.timezone(tz_name).localize(date_time).strftime('%z')
# Test
print(get_utc_offset_by_timezone_name('Asia/Jerusalem', datetime.datetime(2011,1,1)))
