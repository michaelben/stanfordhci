# 4020539
# Process escape sequences in a string in Python

def string_unescape(s):
    return bytes(s, "utf-8").decode("unicode_escape")

print(string_unescape("spam\\neggs"))
