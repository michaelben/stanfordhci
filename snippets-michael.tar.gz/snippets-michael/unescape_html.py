# 2360598
# Unescape HTML entities in a string

import html.parser

def unescape_html_entity(html_text):
    return html.parser.HTMLParser().unescape(html_text)

print(unescape_html_entity('Suzy &amp; John'))
print(unescape_html_entity('&quot;'))
