# 14225676
# Save list of DataFrames to multisheet Excel spreadsheet
from pandas import ExcelWriter
import pandas as pd
def save_xls(list_dfs, xls_path):
    writer = ExcelWriter(xls_path)
    for n, df in enumerate(list_dfs):
        df.to_excel(writer,'sheet%s' % n)
    writer.save()
# Test
save_xls([pd.DataFrame([[1,2,3],[4,5,6],[7,8,9]])], 'output.xlsx')
