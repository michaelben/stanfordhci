# 10073137
# Get first AND last element of tuple at the same time
def get_first_and_last_element_tuple(t):
    return (t[0], t[-1])
# Test
print(get_first_and_last_element_tuple((3,4,4,4,4,4,4,3)))
