# 3852780
# Python -Intersection of multiple lists
def intersection_of_multiple_lists(d):
    return set(d[0]).intersection(*d)
# Test
print(intersection_of_multiple_lists([[1,2,3,4], [2,3,4], [3,4,5,6,7]]))
