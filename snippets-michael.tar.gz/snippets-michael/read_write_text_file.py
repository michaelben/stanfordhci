# 11198718
# Writing to a file in a for loop
def read_write_text_file(src_txtfile, dst_txtfile):
    with open(src_txtfile) as text_file, open(dst_txtfile, 'w') as myfile:  
        for line in text_file:
            var1, var2 = line.split(" ");
            myfile.write(var1+'\n')
# Test
read_write_text_file('new0415.txt', 'xyz0415.txt')
