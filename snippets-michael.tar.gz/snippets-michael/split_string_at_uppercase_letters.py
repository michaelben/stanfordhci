# 2277352
# Python: Split a string at uppercase letters
import re
def split_string_at_uppercase_letters(s):
    return re.findall('[A-Z][^A-Z]*', s)
# Test
print(split_string_at_uppercase_letters('TheLongAndWindingRoad'))
