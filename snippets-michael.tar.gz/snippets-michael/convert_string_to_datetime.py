# 466345
# Convert string into datetime
import time
def convert_string_to_datetime(s, format):
    return time.strptime(s, format)
# Test
print(convert_string_to_datetime('Aug 28 1999 12:00AM', '%b %d %Y %I:%M%p'))
