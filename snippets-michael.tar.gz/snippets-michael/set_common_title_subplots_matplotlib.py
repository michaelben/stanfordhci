# 10717104
# Common title to many subplots in Matplotlib
import matplotlib.pyplot as plt
def set_common_title_subplots_matplotlib(fig, title):
    fig.suptitle(title)
# Test
