# 16729574
# Get a value from a cell of a data frame in Pandas

import numpy as np
import pandas as pd

def get_value_from_cell_pandas(df, x, y):
    return df.iat[x, y]

print(get_value_from_cell_pandas(pd.DataFrame(np.random.randn(5,3),columns=list('ABC')), 0, 0))
