# 1349230
# Matplotlib coord. sys origin to top left
from pylab import *
def coord_top_left_matplotlib():
    A = arange(25)/25.
    A = A.reshape((5,5))

    figure()
    imshow(A, interpolation='nearest', origin='lower')

    figure()
    imshow(A, interpolation='nearest')

    d = arange(5)
    figure()
    plot(d)
    ylim(5, 0)

    show()
# Test
coord_top_left_matplotlib()
