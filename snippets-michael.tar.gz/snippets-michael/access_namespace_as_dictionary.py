# 16878315
# The right way to treat Python argparse.Namespace() as a dictionary
import argparse
def access_namespace_as_dictionary():
    args = argparse.Namespace()
    args.foo = 1
    args.bar = [1,2,3]
    d = vars(args)
    print(d)
# Test
access_namespace_as_dictionary()
