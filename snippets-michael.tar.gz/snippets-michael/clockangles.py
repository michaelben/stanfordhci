# 20601427
# Calculate the angle between the hour and minutes hands
def clockangles(hour, minute):
    ans = abs((hour * 30 + minute * 0.5) - (minute * 6))
    return min(360-ans,ans)
# Test
print(clockangles(7,0))
