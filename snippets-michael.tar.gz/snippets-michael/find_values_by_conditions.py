# 3248542
# find values in an array that meet two conditions using Python
import numpy as np
def find_values_by_conditions(a):
    return np.nonzero((a > 3) & (a < 8))
# Test
print(find_values_by_conditions(np.arange(8)))
