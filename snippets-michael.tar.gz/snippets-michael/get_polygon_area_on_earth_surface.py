# 4681737
# Calculate the area of a polygon on the earth's surface using python
import sys

def get_polygon_area_on_earth_surface():
    try:
        from pyproj import Proj
    except:
        print('need pyproj module installed')
        sys.exit(-1)
    try:
        from shapely.geometry import shape
    except:
        print('need shapely module installed')
        sys.exit(-1)
    co = {"type": "Polygon", "coordinates": [
        [(-102.05, 41.0),
         (-102.05, 37.0),
         (-109.05, 37.0),
         (-109.05, 41.0)]]}
    lon, lat = zip(*co['coordinates'][0])
    pa = Proj("+proj=aea +lat_1=37.0 +lat_2=41.0 +lat_0=39.0 +lon_0=-106.55")
    x, y = pa(lon, lat)
    cop = {"type": "Polygon", "coordinates": [zip(x, y)]}
    return shape(cop).area
# Test
print(get_polygon_area_on_earth_surface())
