# 1296501
# Find Path to File Being Run

import sys
import os
import os.path

def get_path_to_script():
    return os.path.join(os.getcwd(), sys.argv[0])

print(get_path_to_script())
