# 8124606
# Create excel-compatable CSV file with python
import csv
import re

def read_excel_compatable_csv(csvfile):
    def unquoteCsvData(data):
        for x, row in enumerate(data):
            for y, item in enumerate(row):
                if data[x][y] != '':
                    m = re.match(r'="([^"]*)"',data[x][y])
                    if m:
                        data[x][y] =  m.group(1)
        return data

    with open(csvfile, 'r') as fd:
        reader = csv.reader(fd, delimiter=',', 
                                quotechar='|', 
                                quoting=csv.QUOTE_NONE, 
                                escapechar='\\')
        data = []
        for row in reader:
            data.append(row)

    return unquoteCsvData(data)
# Test
print(read_excel_compatable_csv('test2.csv'))
