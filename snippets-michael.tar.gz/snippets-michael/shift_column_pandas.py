# 10982089
# Shift a column in Pandas DataFrame
import pandas as pd
import numpy as np
def shift_column_pandas():
    a = pd.DataFrame({'x1':np.arange(4), 'x2':np.arange(5,9)})
    print(a)
    a.x2 = a.x2.shift(1)
    print(a)
# Test
shift_column_pandas()
