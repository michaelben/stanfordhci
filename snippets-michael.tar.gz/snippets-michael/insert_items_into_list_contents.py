# 1061937
# Modifying list contents in Python
def insert_items_into_list_contents(thelist, *items):
    for sublist in thelist:
        sublist[0:0] = items
    return thelist
# Test
print(insert_items_into_list_contents([[1,2,3],[4,5,6],[7,8,9]], 8, 9))
