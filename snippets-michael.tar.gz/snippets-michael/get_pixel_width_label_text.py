# 8633433
# Qt - Get the pixel length of a string in a QLabel
def get_pixel_width_label_text(label):
    return label.fontMetrics().boundingRect(label.text()).width()
# Test
