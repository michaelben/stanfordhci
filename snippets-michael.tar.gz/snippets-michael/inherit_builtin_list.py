# 9432719
# Python: How can I inherit from the built-in list type?
def inherit_builtin_list():
    class MyList(list):
        def __init__(self, *args):
            list.__init__(self, *args)
            self.append('FirstMen')
            self.name = 'Westeros'

    my_list = MyList([1, 2, 3, 4])
    print(my_list)
# Test
inherit_builtin_list()
