# 19819863
# Convert a single character into it's hex ascii value in python

def get_ascii_value(ch):
	return ord(ch)

print(get_ascii_value('a'))
