# 4789601
# Split a string into 2 in Python
def split_string_into_equal_two(string):
    firstpart, secondpart = string[:len(string)//2], string[len(string)//2:]
    return firstpart, secondpart
# Test
print(split_string_into_equal_two('askdfsfhsf'))
