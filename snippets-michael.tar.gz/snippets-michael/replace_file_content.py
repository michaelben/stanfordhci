# 16604826
# Python Read/Write text file

import shutil
import os
import tmpfile

def replace_file_content(fname=None, replaced=None, replacement=None):
    tmpfname = tmpfile.tmpfile().name
    with open(fname) as old, open(tmpfname, 'w') as new:
        for line in old:
            if replaced in line:
                new.write(replacement+'\n')
            else:
                new.write(line)
    shutil.move(tmpfname, fname)

replace_file_content(fname="test.txt", replaced="AAA", replacement="BBBBB")
