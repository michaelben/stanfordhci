# 8217269
# Decrypting strings in Python that were encrypted with MCRYPT_RIJNDAEL_256 in PHP
import rijndael
import base64

def decrypt_rijndael(key, encoded):
    KEY_SIZE = 16
    BLOCK_SIZE = 32

    padded_key = key.ljust(KEY_SIZE, '\0')

    ciphertext = base64.b64decode(encoded).decode()

    r = rijndael.rijndael(padded_key, BLOCK_SIZE)

    padded_text = ''
    for start in range(0, len(ciphertext), BLOCK_SIZE):
        padded_text += r.decrypt(ciphertext[start:start+BLOCK_SIZE])

    plaintext = padded_text.split('\x00', 1)[0]

    return plaintext
# Test
print(decrypt_rijndael('MyKey', 'I8OiwqXCvwIKw5nDrsK9w5JTw4sNAwxRw75kfcKZwp1lEh7DhcKCacOVIsOWRMKW'))
