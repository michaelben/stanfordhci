# 1889385
# List of dictionaries, in a dictionary - in Python
def create_dict_list_dict_dict():
    rules = {}
    rules['a'] = [{'b':{'f_expr': 'c', 'c_expr': 'd'}}]
    return rules
# Test
print(create_dict_list_dict_dict())
