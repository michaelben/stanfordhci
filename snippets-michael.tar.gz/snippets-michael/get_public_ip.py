# 9481419
# Get the public IP
import requests
from urllib.request import urlopen
from json import load
def get_public_ip():
    try:
      return requests.get('http://ip.42.pl/raw').text
    except:
      try:
        return load(urlopen('http://jsonip.com'))['ip']
      except:
        try:
          return load(urlopen('http://httpbin.org/ip'))['origin']
        except:
          try:
            return load(urlopen('https://api.ipify.org/?format=json'))['ip']
          except:
            print('something wrong.')
# Test
print(get_public_ip())
