# 1158128
# Merge sorted lists in python
import itertools
from decimal import Decimal
def merge_sorted_lists(*args, cmp=None):
    return sorted(itertools.chain(*args))
# Test
print(merge_sorted_lists([Decimal(1), Decimal(3), Decimal(8)],
                   [Decimal(1), Decimal(2), Decimal(2)],
                   [Decimal(100), Decimal(300), Decimal(800)]))
