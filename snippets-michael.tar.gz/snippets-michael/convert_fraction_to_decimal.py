# 4841732
# Python Convert fraction to decimal
from fractions import Fraction
def convert_fraction_to_decimal(fraction):
    return float(fraction)
# Test
print(convert_fraction_to_decimal(Fraction(1,2)))
