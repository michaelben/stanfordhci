# 22976731
# AttributeError: 'list' object has no attribute 'split' when i try to split a row from csv file
def remove_stopwords(filename):
    stopwords = set(['with', 'for', 'It', 'We', 'is', 'and'])
    new_text_list = []
    cachedStopWords = stopwords
    with open(filename, "r") as f:
        next(f)  # skip one line
        for line in f:
            row = line.split()
            text = ' '.join([word for word in row
                             if word not in cachedStopWords])
            print(text)
            new_text_list.append(text)

    return new_text_list
# Test
remove_stopwords('remove_stopwords.py')
