# 18980039
# Append in a json file in Python
import json

def append_to_json_file(jsonfile, adict):
    with open(jsonfile) as f:
        data = json.load(f)

    data.update(adict)

    with open(jsonfile, 'w') as f:
        json.dump(data, f)
# Test
append_to_json_file('test0409.json', {'new_key':'new_value'})
