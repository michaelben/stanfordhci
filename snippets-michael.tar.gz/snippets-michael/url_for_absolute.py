# 12162634
# Where do I define the domain to be used by url_for() in Flask?
def url_for_absolute(url):
    return url_for(url, _external=True)
# Test
