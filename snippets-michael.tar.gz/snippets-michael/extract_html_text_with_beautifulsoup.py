# 7911504
# Python string operation, extract text between html tags
from bs4 import BeautifulSoup as BS
def extract_html_text_with_beautifulsoup():
    bs = BS("""
            <font face="ARIAL,HELVETICA" size="-2">  
            JUL 28         </font>"""
            , 'lxml')
    print(bs.font.contents[0].strip())
# Test
extract_html_text_with_beautifulsoup()
