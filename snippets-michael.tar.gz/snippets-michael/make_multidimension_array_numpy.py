# 2318667
# Make a multidimensional array of arrays in numpy
import numpy as np
def make_multidimension_array_numpy(rows, cols, depths):
    d3array=np.empty((rows, cols), dtype='object')
    d3array[0,0]=np.arange(depths)
    d3array[0,0][0] = 1
    return d3array
# Test
print(make_multidimension_array_numpy(10,10,10)[0,0][0])
