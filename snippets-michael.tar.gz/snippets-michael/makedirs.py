# 4753338
# python creating folder tree dynamically from a string
import os
def makedirs(path):
    try:
        os.makedirs(path)
    except:
        pass
# Test
makedirs('a/b/c')
