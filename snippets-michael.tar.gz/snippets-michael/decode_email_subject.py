# 5259601
# Convert email subject from ?UTF-8?...?= to readable string
from email.header import decode_header
def decode_email_subject(subject):
    return decode_header(subject)[0][0].decode()
# Test
print(decode_email_subject('=?UTF-8?B?0J/RgNC+0LLQtdGA0LrQsA==?='))
