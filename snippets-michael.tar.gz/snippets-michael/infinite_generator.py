# 5737196
# an expression for an infinite generator?
def infinite_generator():
    for x in iter(int, 1): yield x
# Test
print(infinite_generator())
