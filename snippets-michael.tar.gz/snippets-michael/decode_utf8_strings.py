# 13110629
# Decoding UTF-8 strings in Python
import chardet

def decode_utf8_strings(s):
    encoding = chardet.detect(s)
    print(encoding)
    print(s.decode('utf-8'))
# Test
decode_utf8_strings("And the Hipâ€™s coming, too".encode('windows-1252'))
