# 2501675
# Printing elements out of list
def join_string_list(l, sep):
    return sep.join(l)
# Test
print(join_string_list(['1','2','3'], ' '))
