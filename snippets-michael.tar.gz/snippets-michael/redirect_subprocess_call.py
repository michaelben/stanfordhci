# 3982577
# Python: Redirect stdout/stderr on subprocess call
import os
import shutil
import subprocess

def redirect_subprocess_call():
    o = shutil.which('rtmpdump')
    if not o:
        print('no rtmpdump installed?')
        sys.exit(-1)

    RTMPDUMP="./rtmpdump"
    assert os.path.isfile(RTMPDUMP)
    command = [RTMPDUMP,'-r','rtmp://oxy.videolectures.net/video/',
            '-y','2007/pascal/bootcamp07_vilanova/keller_mikaela/bootcamp07_keller_bss_01',
            '-a','video','-s',
            'http://media.videolectures.net/jw-player/player.swf',
            '-w','ffa4f0c469cfbe1f449ec42462e8c3ba16600f5a4b311980bb626893ca81f388'
            ,'-x','53910','-o','test.flv']

    stdout = open("stdout.txt","wb")
    stderr = open("stderr.txt","wb")
    subprocess.call(command,stdout=stdout,stderr=stderr)
# Test
