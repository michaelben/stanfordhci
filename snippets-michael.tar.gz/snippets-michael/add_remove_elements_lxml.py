# 3232618
# Adding attributes to existing elements, removing elements, etc with lxml
from lxml import etree
from io import StringIO

def add_remove_elements_lxml():
    tree = etree.parse(StringIO('<Root><Description><Title>foo</Title></Description></Root>'))
    root=tree.getroot()
    #find element
    title = tree.find("//Title")
    #remove elements
    title.getparent().remove(title)
    #add attribute
    root.attrib['myNewAttribute']='hello world'
    print(etree.tostring(root, pretty_print=True))
# Test
add_remove_elements_lxml()
