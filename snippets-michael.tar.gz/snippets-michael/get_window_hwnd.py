# 14653168
# Get HWND of each Window Python for Windows platform
import sys
import platform
import ctypes

def get_window_hwnd():
    p = platform.platform().split('-')[0]
    if p != 'Windows':
        print('The code only works on Windows platform')
        sys.exit(-1)

    import win32gui

    EnumWindows = ctypes.windll.user32.EnumWindows
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int))
    GetWindowText = ctypes.windll.user32.GetWindowTextW
    GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
    IsWindowVisible = ctypes.windll.user32.IsWindowVisible

    titles = []
    def foreach_window(hwnd, lParam):
        if IsWindowVisible(hwnd):       
            length = GetWindowTextLength(hwnd)
            buff = ctypes.create_unicode_buffer(length + 1)
            GetWindowText(hwnd, buff, length + 1)
            titles.append((hwnd, buff.value))
        return True
    EnumWindows(EnumWindowsProc(foreach_window), 0)

    for i in range(len(titles)):
        print(titles)[i]

    ctypes.windll.user32.MoveWindow((titles)[5][0], 0, 0, 760, 500, True)
# Test
get_window_hwnd()
