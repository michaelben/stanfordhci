# 2329417
# Fastest Way to Delete a Line from Large File in Python
def remove_line_from_file(filename, lineno):
    "lineno starting from 0"
    fro = open(filename, "rb")

    current_line = 0
    while current_line < lineno:
        fro.readline()
        current_line += 1

    seekpoint = fro.tell()
    frw = open(filename, "r+b")
    frw.seek(seekpoint, 0)

    # read the line we want to discard
    fro.readline()

    # now move the rest of the lines in the file 
    # one line back 
    chars = fro.readline()
    while chars:
        frw.write(chars)
        chars = fro.readline()

    fro.close()
    frw.truncate()
    frw.close()
# Test
remove_line_from_file('test.txt.1', 1)
