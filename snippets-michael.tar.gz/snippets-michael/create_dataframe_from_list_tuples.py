# 17004985
# How do I create pandas DataFrame (with index or multiindex) from list of namedtuple instances?
import pandas as pd
from collections import namedtuple

def create_dataframe_from_list_tuples():
    Price = namedtuple('Price', 'ticker date price')
    a = Price('GE', '2010-01-01', 30.00)
    b = Price('GE', '2010-01-02', 31.00)
    l = [a, b]

    df = pd.DataFrame(l, columns=l[0]._fields)
    df.set_index(['ticker', 'date'], inplace=True)

    print(df)
# Test
create_dataframe_from_list_tuples()
