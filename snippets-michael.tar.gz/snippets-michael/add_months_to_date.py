# 6576187
# Ddd 3 months to a datetime.date object in python
from dateutil.relativedelta import relativedelta
import datetime
def add_months_to_date(date, months):
    return date + relativedelta(months=months)
# Test
print(add_months_to_date(datetime.date.today(), 3))
