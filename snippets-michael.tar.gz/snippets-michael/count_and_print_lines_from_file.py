# 11726349
# python looping through input file

def count_and_print_lines_from_file(fname):
    with open(fname) as input_file:
        for i, line in enumerate(input_file):
            print(line)
    print("{0} line(s) printed".format(i+1))

count_and_print_lines_from_file("count_and_print_lines_from_file.py")
