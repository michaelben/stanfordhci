# 7111690
# Python Read Formatted String
import struct
def read_formatted_string_from_file(fname):
    with open(fname, "r") as f:
        for line in f:
            (coop_id, lat, lon, elev, state, name, c1, c2, c3, utc_offset
             ) = struct.unpack("6sx8sx9sx6sx2sx30sx6sx6sx6sx2s", line.strip().encode())
            (lat, lon, elev) = map(float, (lat, lon, elev))
            utc_offset = int(utc_offset)
            print(coop_id.decode(), lat, lon, elev, state.decode(), name.decode(), c1.decode(), c2.decode(), c3.decode(), utc_offset)
# Test
read_formatted_string_from_file('format.txt')
