# 373459
# split string on a number of different characters
import re
def regex_split(s, seps):
    return re.split(seps, s)
# Test
print(regex_split('a b.c', '[ .]'))
