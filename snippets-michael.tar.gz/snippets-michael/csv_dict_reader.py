# 16161082
# Convert string to float in Python
import csv

def csv_dict_reader():
    with open('meteors.csv', 'rU') as csvfile:
         reader=csv.DictReader(csvfile)
         for row in reader:    
             print(row['coordinate_1'])
# Test
