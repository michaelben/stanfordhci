# 18344932
# Subprocess.call, stdout to file, stderr to file, display stderr on screen in real time on *Nix platform

import subprocess

def tee_stderr(tool, log_file):
    tool = subprocess.Popen(tool,\
                            stdout=open(log_file, 'w'), stderr=subprocess.PIPE)
    tee = subprocess.Popen(['tee', log_file], stdin=tool.stderr)
    tool.stderr.close()
    tee.communicate()

tee_stderr(['ls', '-l'], 'log_file')
