# 14940743
# Selecting/Excluding sets of columns in Pandas
import numpy as np
import pandas as pd

def select_drop_columns_pandas():
    df = pd.DataFrame(np.random.randn(100, 4), columns=list('ABCD'))
    print(df)
    #using DataFrame.drop
    df1 = df.drop(df.columns[[1, 2]], axis=1, inplace=True)
    print(df1)
    #drop by name
    #df1 = df.drop(['B', 'C'], axis=1)
    #print(df1)
    #select the ones you want
    df1 = df[['A','D']]
    print(df1)
# Test
select_drop_columns_pandas()
