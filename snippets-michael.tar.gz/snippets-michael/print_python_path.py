# 18486469
# how to print contents of PYTHONPATH
import sys
def print_python_path():
    print(sys.path)
# Test
print_python_path()
