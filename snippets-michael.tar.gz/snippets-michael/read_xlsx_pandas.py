# 16888888
# How to read a .xlsx file using the pandas Library in iPython?
import pandas as pd
def read_xlsx_pandas(xlsx_file):
    xl_file = pd.ExcelFile(file_name)

    dfs = {sheet_name: xl_file.parse(sheet_name) 
                      for sheet_name in xl_file.sheet_names}

    return dfs
# Test
