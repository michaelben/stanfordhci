# 11918999
# Key Listeners in python
import sys
import platform

def key_listeners():
    def linux_key_listener():
        import termios
        import contextlib
        @contextlib.contextmanager
        def raw_mode(file):
            old_attrs = termios.tcgetattr(file.fileno())
            new_attrs = old_attrs[:]
            new_attrs[3] = new_attrs[3] & ~(termios.ECHO | termios.ICANON)
            try:
                termios.tcsetattr(file.fileno(), termios.TCSADRAIN, new_attrs)
                yield
            finally:
                termios.tcsetattr(file.fileno(), termios.TCSADRAIN, old_attrs)

        print('exit with ^C or ^D')
        with raw_mode(sys.stdin):
            try:
                while True:
                    ch = sys.stdin.read(1)
                    if not ch or ch == chr(4):
                        break
                    print('%02x pressed. Exit with ^C or ^D' % ord(ch))
            except (KeyboardInterrupt, EOFError):
                pass

    def windows_key_listener():
        import msvcrt
        import time
        def kbfunc():
            #this is boolean for whether the keyboard has bene hit
            x = msvcrt.kbhit()
            if x:
                #getch acquires the character encoded in binary ASCII
                ret = msvcrt.getch()
            else:
                ret = False
            return ret

        number = 1
        while True:
            x = kbfunc() 
            if x != False and x.decode() == 's':
                print ("STOPPING, KEY:", x.decode())
                break
            elif x != False:
                print ("Press s to exit. KEY: %s pressed." %  x.decode())
            else:
                print ('Press s to exit. %d' % number)
                number += 1
                time.sleep(0.5)

    p = platform.platform().split('-')[0]
    if p == 'Linux':
        linux_key_listener()
    elif p == 'Windows':
        windows_key_listener()
    else:
        print('Your platform may not be supported.\n')
        sys.exit(-1)
# Test
key_listeners()
