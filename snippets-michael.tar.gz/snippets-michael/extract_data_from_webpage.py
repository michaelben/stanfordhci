# 10061544
# Extract data from a web page

import urllib.request
import re

def extract_data_from_webpage(pattern, url):
    response = urllib.request.urlopen(url)
    web_pg = response.read()
    m = re.search(pattern, web_pg.decode())
    for g in m.groups():
        print(g)

extract_data_from_webpage("<td><b>SILVER PASSBOOK ACCOUNT</b></td>" + "<td>(.*)</td>" * 4, "https://uniservices1.uobgroup.com/secure/online_rates/gold_and_silver_prices.jsp")
