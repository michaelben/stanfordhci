# 18366554
# Search for word in text file and print part of line
def search_and_print(fname):
    with open(fname) as openfile:
        for line in openfile:
            for part in line.split():
                if "color=" in part:
                    print(part)
# Test
search_and_print("textfile.txt")
