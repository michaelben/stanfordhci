# 20638006
# Convert list of dictionaries to Dataframe
import pandas as pd
def get_dataframe_from_dict_list(d):
    return pd.DataFrame(d)
# Test
print(get_dataframe_from_dict_list([{'points': 50, 'time': '5:00', 'year': 2010}, 
    {'points': 25, 'time': '6:00', 'month': "february"}, 
    {'points':90, 'time': '9:00', 'month': 'january'}, 
    {'points_h1':20, 'month': 'june'}]))
