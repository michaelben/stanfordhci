# 3376236
# Add a new column of data to a csv file
import csv
from io import StringIO
def get_csv_file_with_added_column( start_file, col ):
    f = csv.reader( start_file )
    def data( csvfile ):
        for line in csvfile:
            yield line + [ col ]
    return data( f )
# Test
print(list(get_csv_file_with_added_column(StringIO('''\
1, asdf, 234
2, dff, 234
3, dfg, 345
'''), 'ggg')))
