# 8822755
# How to save an image using django imageField?
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseNotAllowed
import json

def upload_view(request):
    if request.method == 'POST':
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            result = {'success': True}
            return HttpResponse(json.dumps(result), mimetype='application/json')
        else:
            return HttpResponseBadRequest()
    else:
        return HttpResponseNotAllowed(['POST'])
# Test
