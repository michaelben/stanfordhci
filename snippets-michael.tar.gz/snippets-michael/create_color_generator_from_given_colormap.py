# 3016283
# Create a color generator from given colormap in matplotlib
from pylab import *

def create_color_generator_from_given_colormap():
    NUM_COLORS = 22

    cm = get_cmap('gist_rainbow')
    cgen = (cm(1.*i/NUM_COLORS) for i in range(NUM_COLORS))
    return cgen
# Test
print(list(create_color_generator_from_given_colormap()))
