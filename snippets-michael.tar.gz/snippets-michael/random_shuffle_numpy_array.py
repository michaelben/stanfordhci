# 3891180
# Select cells randomly from NumPy array - without replacement
import numpy as np
def random_shuffle_numpy_array():
    data = np.random.rand(25)
    print(data)
    idx = np.arange(25)
    np.random.shuffle(idx)
    print(data[idx])
# Test
random_shuffle_numpy_array()
