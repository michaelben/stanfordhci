# 15422144
# Read a long multiline string line by line in python
def read_multiline_string(s):
    for line in s.splitlines():
        print(line)
# Test
read_multiline_string('''
        first line
        second line
        ''')
