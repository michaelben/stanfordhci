# 704152
# Convert a character to a integer

def get_ascii(ascii):
    return ord(ascii)

print(get_ascii('a'))
