# 2680391
# In django changing the file name of uploading file
import os.path
def update_filename(instance, filename, path):
    fmt = instance.userid + instance.transaction_uuid + instance.file_extension
    return os.path.join(path, fmt)
#Test
