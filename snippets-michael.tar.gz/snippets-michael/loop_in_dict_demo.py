# 1772068
# List in a dictionary, looping in Python
def loop_in_dict_demo():
    providers = {
        'hotmail':{
            'type':'hotmail',
            'lookup':'mixed',
            'dkim': 'no',
            'signatures':[
                '|S|Return-Path: postmaster@hotmail.com',
                '|R|^Return-Path:\s*[^@]+@(?:hot|msn)',
                '^Received: from .*hotmail.com$']
        },
        'gmail':{
            'type':'gmail',
            'lookup':'mixed',
            'dkim': 'yes',
            'signatures':['|S|Subject: unsubscribe','','','']
        }
    }
    for provider, provider_info in providers.items():
        for sig in provider_info['signatures']:
            if ("|S|" in sig):
                print(sig[3:len(sig)])
            elif ("|R|" in sig):
                print(sig[3:len(sig)])
# Test
loop_in_dict_demo()
