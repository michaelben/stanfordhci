# 5606083
# Set and retrieve cookie in http header

import urllib.request

def get_cookie(url):
    d = urllib.request.urlopen(url)
    return d.getheader('Set-Cookie')

print(get_cookie("http://www.wikipedia.org"))
