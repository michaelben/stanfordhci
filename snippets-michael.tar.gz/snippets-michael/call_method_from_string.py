# 1855558
# Call method from string
def call_method_from_string(variable):
    class CallMe:
        def App():
            print('App is called')
        def Foo():
            pass
    getattr(CallMe, variable)()
# Test
call_method_from_string('App')
