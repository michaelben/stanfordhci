# 2338531
# Python sorting - A list of objects

import operator

def sort_list_by_field_demo():
    class A:
        def __init__(self, i, resultType):
            self.i = i
            self.resultType = resultType
    
    myList = [ A(1, 2), A(2, 3), A(23, 1) ]
    print([(A.i, A.resultType) for A in myList])
    myList.sort(key = operator.attrgetter('resultType'))
    print([(A.i, A.resultType) for A in myList])

sort_list_by_field_demo()
