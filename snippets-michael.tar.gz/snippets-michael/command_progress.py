# 7632589
# Getting realtime output from ffmpeg to be used in progress bar (PyQt4, stdout)
import pexpect
import shutil
import sys

def command_progress():
    prog = shutil.which('ffmpeg')
    if not prog:
        print('ffmpeg is needed')
        sys.exit(-1)

    cmd = 'ffmpeg -i file.MTS file.avi'
    thread = pexpect.spawn(cmd)
    print("started %s" % cmd)
    cpl = thread.compile_pattern_list([
        pexpect.EOF,
        "frame= *\d+",
        '(.+)'
    ])
    while True:
        i = thread.expect_list(cpl, timeout=None)
        if i == 0: # EOF
            print("the sub process exited")
            break
        elif i == 1:
            frame_number = thread.match.group(0)
            print(frame_number)
            thread.close
        elif i == 2:
            #unknown_line = thread.match.group(0)
            #print unknown_line
            pass
# Test
command_progress()
