# 17921010
# Query MultiIndex index columns values in pandas
import numpy as np
import pandas as pd
def query_multiindex_columns_pandas():
    A = np.array([1.1, 1.1, 3.3, 3.3, 5.5, 6.6])
    B = np.array([111, 222, 222, 333, 333, 777])
    C = np.random.randint(10, 99, 6)
    df = pd.DataFrame(list(zip(A, B, C)), columns=['A', 'B', 'C'])
    df.set_index(['A', 'B'], inplace=True)
    print(df)
    result_df = df.loc[(df.index.get_level_values('A') > 1.7) & (df.index.get_level_values('B') < 666)]
    print(result_df)
    print(result_df.index.get_level_values('A'))
# Test
query_multiindex_columns_pandas()
