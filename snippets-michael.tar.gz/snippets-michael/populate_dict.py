# 10601601
# Populating a Python dictionary
from collections import defaultdict

def populate_dict():
    customers = defaultdict(list)
    customers['customer1'].append(('milk', 3))
    customers['customer1'].append(('bread', 5))
    customers['customer2'].append(('cereal', 7))
    return customers
# Test
print(populate_dict())
