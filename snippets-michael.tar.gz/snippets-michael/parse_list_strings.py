# 330900
# quickly parse a list of strings
import csv

def parse_list_strings():
    input = ['abc,"a string, with a comma","another, one"']
    parser = csv.reader(input)

    for fields in parser:
        for i, f in enumerate(fields):
            print(i, f)
# Test
parse_list_strings()
