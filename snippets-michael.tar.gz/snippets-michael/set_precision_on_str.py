# 4844865
# Set the precision on numpy.float64
import numpy as np
def set_precision_on_str():
    foo = np.array([1.22334])
    print('%.2f' % foo[0])
# Test
set_precision_on_str()
