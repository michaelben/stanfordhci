# 8991506
# Iterate an iterator by chunks (of n) in Python
import itertools
def iterator_grouper_general(n, iterable):
    ''' work on general iterable '''
    it = iter(iterable)
    while True:
        chunk = tuple(itertools.islice(it, n))
        if not chunk:
            return
        yield chunk
# Test
print(list(iterator_grouper_general(3, [1,2,3,4,5,6,7])))
