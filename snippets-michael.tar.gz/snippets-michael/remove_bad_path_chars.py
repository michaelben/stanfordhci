# 1033424
# Remove bad path characters in Python
def remove_bad_path_chars(value, deletechars):
    for c in deletechars:
        value = value.replace(c,'')
    return value;

# Test
print(remove_bad_path_chars('\sajf23<>', '\/:*?"<>|'))
