# 12668027
# Expand a numpy ndarray
import numpy as np
def expand_numpy_ndarray(arr1, arr2):
    return np.concatenate((arr1, arr2), axis=1)
# Test
print(expand_numpy_ndarray(np.array([[1, 2], [3, 4]]), np.zeros((2, 3))))
