# 13994594
# Add timezone into a naive datetime instance in python
from datetime import datetime, timedelta
from pytz import timezone
import pytz
def timezone_localize():
    utc = pytz.utc
    print(utc.zone)
    eastern = timezone('US/Eastern')
    print(eastern.zone)
    amsterdam = timezone('Europe/Amsterdam')
    fmt = '%Y-%m-%d %H:%M:%S %Z%z'
    loc_dt = eastern.localize(datetime(2002, 10, 27, 6, 0, 0))
    print(loc_dt.strftime(fmt))
    ams_dt = loc_dt.astimezone(amsterdam)
    print(ams_dt.strftime(fmt))
# Test
timezone_localize()
