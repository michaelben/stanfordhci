# 1591579
# Update/modify a XML file

import xml.etree.ElementTree 

def update_xml(src_file=None, dest_file=None):
    # Open original file
    et = xml.etree.ElementTree.parse(src_file)

    # Append new tag: <a x='1' y='abc'>body text</a>
    new_tag = xml.etree.ElementTree.SubElement(et.getroot(), 'a')
    new_tag.text = 'body text'
    new_tag.attrib['x'] = '1' # must be str; cannot be an int
    new_tag.attrib['y'] = 'abc'

    et.write(dest_file)

update_xml(src_file="test.xml", dest_file="out.xml")
