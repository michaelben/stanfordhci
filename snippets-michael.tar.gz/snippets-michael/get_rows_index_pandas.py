# 21800169
# Python Pandas: Get index of rows which column matches certain value

import pandas as pd

def get_rows_index_pandas(df, col):
    idx = df[df[col] == True].index.tolist()
    return df.loc[idx]

print(get_rows_index_pandas(pd.DataFrame({'BoolCol': [True, False, False, True, True]}, index=[10,20,30,40,50]),
 'BoolCol'))
