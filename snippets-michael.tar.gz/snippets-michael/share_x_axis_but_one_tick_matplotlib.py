# 4209467
# matplotlib share x axis but don't show x axis tick labels for both, just one

import matplotlib.pyplot as plt

def share_x_axis_but_one_tick():
    fig = plt.figure()
    ax1 = fig.add_subplot(2,1,1)
    ax1.plot(range(10), 'b-')

    ax2 = fig.add_subplot(2,1,2, sharex=ax1)
    ax2.plot(range(10), 'r-')

    plt.setp(ax1.get_xticklabels(), visible=False)

    plt.show()

share_x_axis_but_one_tick()
