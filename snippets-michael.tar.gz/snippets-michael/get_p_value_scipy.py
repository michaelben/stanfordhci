# 17559897
# P-value from Chi sq test statistic in Python
import numpy as np
from scipy import stats

def get_p_value_scipy(x):
    m, v, s, k = stats.t.stats(10, moments='mvsk')
    n, (smin, smax), sm, sv, ss, sk = stats.describe(x)
    tt = (sm-m)/np.sqrt(sv/float(n))  # t-statistic for mean
    pval = stats.t.sf(np.abs(tt), n-1)*2  # two-sided pvalue = Prob(abs(t)>tt)
    return (tt, pval)
# Test
print(get_p_value_scipy(stats.t.rvs(10, size=1000)))
