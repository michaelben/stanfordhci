# 243865
# Merge two python iterators
import itertools
def imerge(a, b):
    for i, j in zip(a,b):
        yield i
        yield j
# Test
print(list(imerge(['foo', 'bar'], itertools.count(1))))
