# 5509302
# Skip N values of the iteration variable in Python
def skip_nvalues_iteration():
    iterable = iter(range(100))
    for i in iterable:
        if i % 10 == 0:
            print([next(iterable) for x in range(10)])
# Test
skip_nvalues_iteration()
