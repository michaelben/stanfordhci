# 17068966
# Write python array (data = []) to excel
import xlwt
from tempfile import TemporaryFile
def write_to_excel(fname):
    book = xlwt.Workbook()
    sheet1 = book.add_sheet('sheet1')

    a=[1,2,3,4,5]
    b=[6,7,8,9,10]
    c=[2,3,4,5,6]

    data = [a,b,c]

    for row, array in enumerate(data):
        for col, value in enumerate(array):
            sheet1.write(row, col, value)

    book.save(fname)
    book.save(TemporaryFile())
# Test
write_to_excel('this.xls')
