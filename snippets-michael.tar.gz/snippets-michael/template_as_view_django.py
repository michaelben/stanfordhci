# 5201346
# How do I go straight to template, in Django's urls.py?
from django.views.generic import TemplateView

def template_as_view_django():
    urlpatterns = patterns('',
        (r'^foo/$', TemplateView.as_view(template_name='foo.html')),
    )
# Test
