# 13779526
# Find substring within a list

def substr_in_list(myList, sub):
	return [s for s in myList if sub in s]

print(substr_in_list(['abc123', 'def456', 'ghi789'], 'abc'))
