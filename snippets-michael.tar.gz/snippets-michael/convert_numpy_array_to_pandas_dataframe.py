# 21938932
# Convert a numpy array into a pandas dataframe
import numpy as np
import pandas as pd
def convert_numpy_array_to_pandas_dataframe(px):
    px2 = px.reshape((-1,3))
    df = pd.DataFrame({'R':px2[:,0],'G':px2[:,1],'B':px2[:,2]})
    print(df)
# Test
convert_numpy_array_to_pandas_dataframe(np.array([1,2,3,4,5,6,7,8,9]))
