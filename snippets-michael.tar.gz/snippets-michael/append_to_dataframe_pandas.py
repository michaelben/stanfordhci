# 19365513
# Add an extra row to a pandas dataframe

import pandas as pd

def append_to_dataframe_pandas(dataframe, row):
    dataframe.loc[len(dataframe)] = row
    return dataframe

append_to_dataframe_pandas(pd.DataFrame(columns=['Date', 'Name','Action','ID']), ['8/19/2014','Jun','Fly','98765'])
