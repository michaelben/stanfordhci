# 1024143
# Stop Python parse_qs from parsing single values into lists
import urllib.parse as urlparse
def stop_parse_qs_into_list(qsdata):
    return dict( (k, v if len(v)>1 else v[0] ) 
           for k, v in urlparse.parse_qs(qsdata).items() )
# Test
print(stop_parse_qs_into_list("test=test&test2=test2&test2=test3"))
