# 3040904
# Save JSON outputed from a URL to a file
import urllib.request
def save_json_from_url_to_file(url, jsonfile):
    hi_web = urllib.request.urlopen(url)
    with open(jsonfile, 'ab') as hi_file:
          hi_file.write(hi_web.read())
# Test
save_json_from_url_to_file('http://search.twitter.com/search.json?q=hi', 'test0423.json')
