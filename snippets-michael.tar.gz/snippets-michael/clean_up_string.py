# 3621296
# python: cleaning up a string
import re
def clean_up_string(s):
    rx = re.compile('\W+')
    return rx.sub(' ', s).strip()
# Test
print(clean_up_string('in this/ string / i have many. interesting.occurrences of {different chars} that need     to .be removed  '))
