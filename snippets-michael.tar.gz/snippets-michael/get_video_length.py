# 3844430
# Get video duration in Python or Django
import subprocess
import shutil
import sys
import os.path

def get_video_length(videoname):
    prog = shutil.which('ffprobe')
    if not prog:
        print('need ffprobe installed')
        sys.exit(-1)

    if not os.path.isfile(videoname):
        print(videoname + ' does not exist')
        sys.exit(-2)

    result = subprocess.Popen(["ffprobe", videoname],
                  stdout = subprocess.PIPE, stderr = subprocess.STDOUT)
    return [x for x in result.stdout.readlines() if "Duration" in x]
# Test
print(get_video_length('test.mp'))
