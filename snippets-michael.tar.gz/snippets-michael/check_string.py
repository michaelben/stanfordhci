# 5214578
# Check if string is in a text file and print the line
import re
def check_string(fn, s):
    with open(fn) as f:
        found = False
        for line in f:
            if re.search(r"\b{}\b".format(s), line):
                print(line)
                found = True
        if not found:
            print('Not found!')
# Test
check_string('check_string.py', 'import')
