# 1302161
# How do I parse timezones with UTC offsets in Python?
from dateutil.parser import parse
def parse_timezone_utc_offset(timestr):
    return parse(timestr)
# Test
print(parse_timezone_utc_offset("2009-08-18 13:52:54-04"))
