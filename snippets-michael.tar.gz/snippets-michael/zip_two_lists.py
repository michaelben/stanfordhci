# 21098350
# Python iterate over two lists simultaneously
def zip_two_lists(a, b):
    for x, y in zip(a, b):
        print(x, y)
# Test
zip_two_lists([1,2,3],[4,5,6])
