# 409732
# Python: Alter elements of a list
def alter_list_element(bool_list, bool_value):
    bool_list[:] = [bool_value] * len(bool_list)
    return bool_list
# Test
print(alter_list_element([True, True, False], False))
