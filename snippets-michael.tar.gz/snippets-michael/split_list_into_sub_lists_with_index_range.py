# 18570740
# Python: Split a list into sub-lists based on index ranges
def split_list_into_sub_lists_with_index_range():
    l = ['a','b','c','d','e']
    c_index = l.index("c")
    l2 = l[:c_index]
    return l2
# Test
print(split_list_into_sub_lists_with_index_range())
