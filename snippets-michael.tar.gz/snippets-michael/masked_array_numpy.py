# 12708807
# Numpy integer nan
import numpy as np
def masked_array_numpy():
    a = np.ma.array([1,2,3,4,5], dtype=int)
    a[1] = np.ma.masked
    print(a)
# Test
masked_array_numpy()
