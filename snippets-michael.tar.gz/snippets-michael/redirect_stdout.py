# 4675728
# Redirect stdout to a file

import sys

def redirect_stdout(file):
    sys.stdout = open(file, 'w')
