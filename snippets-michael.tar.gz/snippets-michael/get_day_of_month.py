# 4934783
# Get the day of the month as an integer
import datetime
def get_day_of_month():
    return datetime.datetime.today().day
# Test
print(get_day_of_month())
