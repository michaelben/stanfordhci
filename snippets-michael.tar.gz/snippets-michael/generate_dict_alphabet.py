# 453576
# Fast way to generate a dict of the alphabet
import string
def generate_dict_alphabet():
    return dict.fromkeys(string.ascii_lowercase, 0)
# Test
print(generate_dict_alphabet())
