# 734893
# Python mechanize - two buttons of type 'submit'

from mechanize import Browser

def submit_specific_button_mechanize(url, form, submit_name, submit_label):
	br = Browser()
	br.open(url)
	br.select_form(name=form)
	submit_response = br.submit(name=submit_name, label=submit_label)
	return submit_response

print(submit_specific_button_mechanize("http://michaelben.github.io/product-catalog-demo/test/formexample.html", "form1", 'button_2', 'Two'))
