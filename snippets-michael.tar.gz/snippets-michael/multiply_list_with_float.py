# 29752360
# Python : TypeError: can't multiply sequence by non-int of type 'float'
def multiply_list_with_float(l, f):
    return [i*f for i in l]
# Test
print(multiply_list_with_float([0.0, 1.1, 2.2], 2.0))
