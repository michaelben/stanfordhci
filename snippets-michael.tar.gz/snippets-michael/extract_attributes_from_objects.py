# 2739800
# Extract list of attributes from list of objects in python
def extract_attributes_from_objects():
    class myClass(object):
        def __init__(self, attr):
            self.attr = attr
            self.other = None

    objs = [myClass (i) for i in range(10)]

    attrs = (o.attr for o in objs)
    return attrs
# Test
print(list(extract_attributes_from_objects()))
