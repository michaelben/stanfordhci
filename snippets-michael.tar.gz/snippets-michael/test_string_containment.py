# 6838238
# Comparing a string to multiple items in Python
def test_string_containment(facility, accepted_strings):
    if facility in accepted_strings:
        return True
    else:
        return False
# Test
print(test_string_containment('aaa', {'auth', 'authpriv', 'daemon'}))
