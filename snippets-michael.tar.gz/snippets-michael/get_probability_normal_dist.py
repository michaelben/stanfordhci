# 12412895
# Calculate probability in normal distribution given mean, std

import scipy.stats

def get_probability_normal_dist(mean, std, x):
    return scipy.stats.norm(mean, std).pdf(x)

print(get_probability_normal_dist(0, 1, 0))
