# 4019081
# Copy a sqlite table from a disk database to a memory database in python
import sqlite3

def copy_to_memory_database_sqlite(db):
    new_db = sqlite3.connect(':memory:') # create a memory database
    old_db = sqlite3.connect(db)
    query = "".join(line for line in old_db.iterdump())
    # Dump old database in the new one. 
    new_db.executescript(query)
# Test
copy_to_memory_database_sqlite('test.db')
