# 1400608
# Empty a list

def empty_list(l):
    l[:] = []
    return l

print(empty_list([1, 2, 3]))
