# 2333872
# atomic writing to file with Python
import os
import time

def atomic_write_to_file(fname, text):
    try:
        tmpFile = str(time.time())
        f = open(tmpFile, 'w')
        f.write(text)
        f.flush()
        os.fsync(f.fileno()) 
        f.close()

        os.rename(tmpFile, fname)
    except:
        os.remove(tmpFile)
# Test
atomic_write_to_file('test0421.txt', 'test data')
