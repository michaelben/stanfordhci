# 18777873
# Convert RGB to black OR white
from PIL import Image 
def convert_rgb_to_bw_dither(src, dest):
    image_file = Image.open(src) # open colour image
    image_file = image_file.convert('1') # convert image to black and white
    image_file.save(dest)
# Test
convert_rgb_to_bw_dither('Desert.jpg.2', 'Desert_bw_dither.jpg')
