# 18777873
# Convert RGB to black OR white
from PIL import Image 
def convert_rgb_to_bw(src, dest):
    col = Image.open(src)
    gray = col.convert('L')
    bw = gray.point(lambda x: 0 if x<128 else 255, '1')
    bw.save(dest)
# Test
convert_rgb_to_bw('Desert.jpg.2', 'Desert_bw.jpg')
