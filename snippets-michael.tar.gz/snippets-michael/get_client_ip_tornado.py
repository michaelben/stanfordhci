# 24237091
# Get the client IP of a Tornado request
import tornado
def get_client_ip_tornado():
    class SocketHandler(tornado.websocket.WebSocketHandler):
        def open(self):
            logging.info('Client IP:' + self.request.remote_ip) 
# Test
