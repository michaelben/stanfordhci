# 3495964
# In django call the subcommand 'syncdb' from the initialization script
from django.core.management import call_command
def call_syncdb_django():
    call_command('syncdb', interactive=True)
# Test
