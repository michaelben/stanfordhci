# 228702
# How to get hex string from signed integer
def convert_signed_integer_to_hex_string(n):
    return hex (n & 0xffffffff)[:-1]
# Test
print(convert_signed_integer_to_hex_string(-1))
