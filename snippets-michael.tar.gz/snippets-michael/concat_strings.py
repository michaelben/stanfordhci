# 2133571
# Most Pythonic way to concatenate strings
def concat_strings(l):
    return ''.join(l)
# Test
print(concat_strings(['o','s','s','a','m','a']))
