# 3525953
# Check if all values of iterable are zero
def check_all_values_zero(values):
    return all(v == 0 for v in values)
# Test
print(check_all_values_zero((0, 0, 0, 0, 0)))
