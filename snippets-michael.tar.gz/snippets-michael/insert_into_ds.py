# 18817789
# Add values to existing dictionary key

def insertIntoDataStruct(name,startTime,endTime,aDict):
    if not name in aDict:
        aDict[name] = [(startTime,endTime)]
    else:
        aDict[name].append((startTime,endTime))
    return aDict

print(insertIntoDataStruct("CS 2316", "1505", "1555", {}))
