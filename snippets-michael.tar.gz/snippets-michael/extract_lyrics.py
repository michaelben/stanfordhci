# 14288177
# Interact with other programs: extract song lyrics
#!/usr/bin/env python
import codecs
import json
import sys
import urllib.parse
import urllib.request

import bs4  # pip install beautifulsoup4

def extract_lyrics(artist, song):
    """Extract lyrics text from given lyrics.wikia.com html page."""
    query = urllib.parse.urlencode(dict(artist=artist, song=song, fmt="json"))
    response = urllib.request.urlopen("http://lyrics.wikia.com/api.php?" + query).read().decode()
    data = json.loads(response)
    if data['lyrics'] != 'Not found':
        # print short lyrics
        print(data['lyrics'])
        page = urllib.request.urlopen(data['url'])
        # get full lyrics
        soup = bs4.BeautifulSoup(page)
        result = []
        for tag in soup.find('div', 'lyricbox'):
            if isinstance(tag, bs4.NavigableString):
                if not isinstance(tag, bs4.element.Comment):
                    result.append(tag)
            elif tag.name == 'br':
                result.append('\n')
        lyrics = "".join(result)
        # save to file
        filename = "[%s] [%s] lyrics.txt" % (data['artist'], data['song'])
        with codecs.open(filename, 'w', encoding='utf-8') as output_file:
            output_file.write(lyrics)
        print("written '%s'" % filename)
    else:
        sys.exit('not found')
# Test
extract_lyrics('Queen', 'We are the Champions')
