# 29448934
# Extract links from a webpage using lxml, XPath and Python
from lxml import etree
import lxml.html    

def extract_data_from_webpage_lxml_xpath():
    collected = [] #list-tuple of [(col1, col2...), (col1, col2...)]
    dom = lxml.html.parse("http://gbgfotboll.se/serier/?scr=table&ftid=57108")
    #all table rows
    xpatheval = etree.XPathDocumentEvaluator(dom)
    rows = xpatheval("""//div[@id="content-primary"]/table[
        contains(concat(" ", @class, " "), " clTblStandings ")]/tbody/tr""")

    for row in rows:
        collumns = row.findall("td")
        collected.append((
            collumns[0].find("a").text.encode("utf8"), # Lag
            collumns[1].text, # S
            collumns[5].text, # GM-IM
            collumns[7].text, # P - last collumn
        ))

    for i in collected: print(i)
# Test
extract_data_from_webpage_lxml_xpath()
