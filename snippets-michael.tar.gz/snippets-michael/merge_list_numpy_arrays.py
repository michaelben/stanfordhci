# 6030906
# Merging a list of numpy arrays into one array (fast)
import numpy

def merge_list_numpy_arrays(width=320, height=320, n_matrices=80):
    firstmatrices = list()
    for i in range(n_matrices):
        temp = numpy.random.rand(height, width).astype(numpy.float32)
        firstmatrices.append(numpy.round(temp*9))

    first2 = firstmatrices.pop()
    for i in range(len(firstmatrices)):
        first2 = numpy.vstack((firstmatrices.pop(),first2))

    return first2
# Test
merge_list_numpy_arrays()
