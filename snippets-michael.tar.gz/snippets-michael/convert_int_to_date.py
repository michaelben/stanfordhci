# 9750330
# Convert integer into date object python
import datetime
def convert_int_to_date(i):
    return datetime.datetime.strptime(str(i), '%Y%m%d')
# Test
print(convert_int_to_date(20120213))
