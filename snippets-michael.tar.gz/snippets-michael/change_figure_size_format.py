# 17109608
# change figure size and figure format in matplotlib
import matplotlib.pyplot as plt
def change_figure_size_format():
    list1 = [3,4,5,6,9,12]
    list2 = [8,12,14,15,17,20]
    plt.plot(list1, list2)
    plt.figure(figsize=(3,4))
    plt.savefig('fig0416.tiff', dpi = 300)
    plt.close()
# Test
change_figure_size_format()
