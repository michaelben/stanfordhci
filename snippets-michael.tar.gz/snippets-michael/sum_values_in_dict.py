# 4880960
# Python - sum values in dictionary
def sum_values_in_dict(myList):
    return sum(item['gold'] for item in myList)
# Test
print(sum_values_in_dict([
        {'points': 400, 'gold': 2480},
        {'points': 100, 'gold': 610},
        {'points': 100, 'gold': 620},
        {'points': 100, 'gold': 620}
]))
