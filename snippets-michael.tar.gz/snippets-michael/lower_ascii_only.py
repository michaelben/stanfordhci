# 638893
# Most efficient way to convert a string to all lowercase stripping out all non-ascii alpha characters

import string, re, timeit

def lower_ascii_only(s):
    return ''.join(list(filter(lambda x: x in string.ascii_lowercase, s.lower())))

print(lower_ascii_only("A235th@#$&( er Ra{}|?>ndom"))
