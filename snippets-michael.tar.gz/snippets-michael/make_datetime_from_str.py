# 7500864
# Python array of datetime objects from numpy ndarray
import numpy as np
import datetime as dt

def make_datetime_from_str(text):
        return dt.datetime.strptime(text, '%Y-%m-%dT%H:%M:%S:%f')    
# Test
