# 3070242
# Reduce python list of objects to dict object.id -> object
def object_list_to_object_dict(object_list):
    return dict((x.iid, x) for x in object_list)
# Test
class Obj:
    iid = 0;
    data = None;
    def __init__(self, iid=0, data=None):
        self.iid = iid
        self.data = data
print(object_list_to_object_dict([Obj(0, 'a'), Obj(1, 'b'), Obj(2, 'c')]))
