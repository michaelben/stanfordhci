# 7580532
# Check whether a method exists in an object

def if_method_exists(mymethod, obj):
    return mymethod in dir(obj)

print(if_method_exists('split', 'afd'))
