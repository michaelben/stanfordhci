# 17411966
# printing stdout in realtime from a subprocess that requires stdin
import subprocess

def subprocess_pipe_stdout_stdin(cmd, input_data):
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stdin=subprocess.PIPE)
    # Send input to p.
    p.stdin.write(input_data.encode())
    p.stdin.flush()
    # Grab stdout line by line as it becomes available.
    # This will loop until terminates.
    while p.poll() is None:
        l = p.stdout.readline() # This blocks until it receives a newline.
        print(l)
    # When the subprocess terminates there might be unconsumed output 
    # that still needs to be processed.
    print(p.stdout.read())
# Test
subprocess_pipe_stdout_stdin('dir', 'test data')
