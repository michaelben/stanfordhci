# 20067636
# Pandas dataframe get first row of each group
import pandas as pd
def get_first_row_each_group_pandas(df):
    return df.groupby('id').first()
# Test
print(get_first_row_each_group_pandas(pd.DataFrame({'id' : [1,1,1,2,2,3,3,3,3,4,4,5,6,6,6,7,7],
                    'value'  : ["first","second","second","first",
                                "second","first","third","fourth",
                                "fifth","second","fifth","first",
                                "first","second","third","fourth","fifth"]})))
