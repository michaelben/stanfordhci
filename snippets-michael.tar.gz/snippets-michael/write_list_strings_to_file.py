# 5429064
# Write list of strings to file, adding newlines

def write_list_strings_to_file(nums, s_chars, fname):
     data = open(fname, "w")
     for c in s_chars:
        for n in nums:
            data.write("%s%s\n" % (c, n))
     data.close()

write_list_strings_to_file(['09', '98', '87', '76', '65', '54', '43'], ['*', '&', '^', '%', '$', '#', '@',], "list.txt")
