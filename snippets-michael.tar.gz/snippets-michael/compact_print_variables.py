# 3249949
# Print a string of variables without spaces in Python (minimal coding!)
def compact_print_variables(*args):
    print("\n"+'|'.join(map(str,list(args))))
# Test
compact_print_variables(12, 'join', 'h', 'johnny', 'mba')
