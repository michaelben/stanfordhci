# 7775106
# check if a line exists in a file python
import os.path
import sys

def check_line_exists_in_file(line, logfilename):
    if not os.path.isfile(logfilename):
        print(logfilename + ' does not exist')
        sys.exit(-1)

    logfile = open(logfilename, 'r')
    loglist = logfile.readlines()
    logfile.close()
    found = False
    for l in loglist:
        if str(line) in l:
            print("Found it")
            found = True
            break

    if not found:
        logfile = open(logfilename, 'a')
        logfile.write(str(line)+"\n")
        logfile.close()
# Test
check_line_exists_in_file('client.host.name', 'ip.log')
