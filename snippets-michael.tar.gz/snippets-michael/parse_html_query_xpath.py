# 2558056
# Parse HTML with lxml.html, and query the parsed HTML with XPath
from lxml import html
def parse_html_query_xpath(text):
    tree = html.fromstring(text)
    return [td.text for td in tree.xpath("//td")]
# Test
print(parse_html_query_xpath('<html><table><tr><td>Header</td></tr><tr><td>Want This</td> </tr></table></html>'))
