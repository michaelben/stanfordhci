# 5522031
# Convert TimeDiff to total seconds

from datetime import timedelta

def total_seconds(timedelta):
    return timedelta.total_seconds()

print(total_seconds(timedelta(days=365)))
