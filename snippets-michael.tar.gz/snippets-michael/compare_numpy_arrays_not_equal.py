# 6628793
# Comparing elements of numpy arrays in python
import numpy as np
def compare_numpy_arrays_not_equal(arr1, arr2):
    return (arr1 != arr2).any()
# Test
print(compare_numpy_arrays_not_equal(np.array([ 150,  25,  100]), [150,25,75]))
