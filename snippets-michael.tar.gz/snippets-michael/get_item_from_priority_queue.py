# 9287919
# Can I get an item from a PriorityQueue without removing it yet?
from queue import PriorityQueue

def get_item_from_priority_queue():
    a = PriorityQueue()

    a.put((10, "a"))
    a.put((4, "b"))
    a.put((3,"c"))

    print(a.queue)
    print(a.get())
    print(a.queue)
    print(a.get())
    print(a.queue)
# Test
get_item_from_priority_queue()
