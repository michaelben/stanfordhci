# 6048085
# Write in a file with python 3 & unicode
def write_unicode_to_file(fname, unistr):
    with open(fname, 'w', encoding='utf8') as f:
        f.write(unistr)
# Test
write_unicode_to_file('test.txt.2.1', u'Δ, Й, ק')
