# 1038824
# Remove a substring from the end of a string

def rclip(s, sub):
    if s.endswith(sub):
        return s[:-len(sub)]

print(rclip('abcdc.com', '.com'))
