# 5557214
# CRC32 checksum in Python with hex input
import binascii
def crc32_hex_binascii(hex):
    return binascii.crc32(binascii.a2b_hex(hex))
# Test
print(crc32_hex_binascii('18329a7e'))
