# 3351218
# Python match a string with regex
def string_contains(s, substr):
    if substr in s.lower():
        return True
    else:
        return False
# Test
print(string_contains('SUBJECT123', 'subject'))
