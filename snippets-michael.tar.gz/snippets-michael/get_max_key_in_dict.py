# 3108042
# Get max key in dictionary
def get_max_key_in_dict(d):
    return max(d, key=int)
# Test
print(get_max_key_in_dict({u'10': 1, u'1': 2, u'3': 2, u'2': 2, u'5': 2, u'4': 2, u'7': 2, u'6': 2, u'9': 2, u'8': 2}))
