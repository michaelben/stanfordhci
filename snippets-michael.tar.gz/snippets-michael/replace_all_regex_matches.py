# 4338032
# replacing all regex matches in single line
import re
def replace_all_regex_matches(text):
    return re.sub("(this)(.*)(string)",
                   r'<markup>\1</markup>\2<markup>\3</markup>',
                          text)
# Test
print(replace_all_regex_matches("this is my string"))
