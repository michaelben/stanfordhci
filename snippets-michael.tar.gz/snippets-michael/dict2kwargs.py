# 5710391
# Converting Python dict to kwargs

def dict2kwargs(**kwargs):
    print(kwargs)

dict2kwargs(**{"type": "event"})
