# 3507283
# Strip comment tags from HTML using BeautifulSoup
from bs4 import BeautifulSoup, Comment
def strip_comment_beatifulsoup(html_str):
    soup = BeautifulSoup(html_str, 'lxml')
    comments = soup.findAll(text=lambda text:isinstance(text, Comment))
    [comment.extract() for comment in comments]
    return soup
# Test
print(strip_comment_beatifulsoup("""1<!--The loneliest number-->
                                    <a>2<!--Can be as bad as one--><b>3"""))
