# 5881309
def create_tuple(a):
    return tuple(a.instances["name_"+str(i)] for i in range(4))
# Test
