# 7887897
# Calculate number of days between two dates inside Django templates
from datetime import datetime, timedelta
from django import template
from django.utils.timesince import timesince
from django.conf import settings

def days_until(value):
    register = template.Library()

    @register.filter
    def time_until(value):
        now = datetime.now()
        try:
            difference = value - now
        except:
            return value

        if difference <= timedelta(minutes=1):
            return 'just now'
        return '%(time)s ago' % {'time': timesince(value).split(', ')[0]}

    return time_until(value)
# Test
print(days_until(datetime.now()))
