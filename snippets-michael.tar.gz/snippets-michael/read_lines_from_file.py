# 328059
# Create a List that contain each Line of a File

def read_lines_from_file(fname):
    return open(fname).readlines()

print(read_lines_from_file("read_lines_from_file.py"))
