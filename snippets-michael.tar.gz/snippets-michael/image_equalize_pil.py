# 7116113
# Normalize histogram (brightness and contrast) of a set of images using Python Image Library (PIL)
import operator
from PIL import Image
from functools import reduce

def image_equalize_pil(im):
    w = 256
    h = im.convert("L").histogram()
    lut = []
    for b in range(0, len(h), w):
        # step size
        step = reduce(operator.add, h[b:b+w]) / (w-1)
        # create equalization lookup table
        n = 0
        for i in range(w):
            lut.append(n / step)
            n = n + h[i+b]
    # map image through lookup table
    # return im.point(lut*im.layers)
    return im.point(lut*3)
# Test
image_equalize_pil(Image.open('Desert.jpg.1'))
