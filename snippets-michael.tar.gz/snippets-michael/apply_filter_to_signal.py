# 13740348
# Apply a filter to a signal in python
import numpy as np
import scipy.signal
def apply_filter_to_signal(input_signal, N=5, Wn=0.5):
    b, a = scipy.signal.butter(N, Wn, 'low')
    output_signal = scipy.signal.filtfilt(b, a, input_signal)
    return output_signal
# Test
print(apply_filter_to_signal(np.arange(1000)))
