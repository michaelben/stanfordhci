# 1058902
# Append two strings

def append_two_strings(s1, s2):
    return ''.join([s1, s2])

print(append_two_strings('sadfjlk', '23423'))
