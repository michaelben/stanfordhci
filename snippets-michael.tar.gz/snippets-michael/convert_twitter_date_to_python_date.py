# 7703865
# Going from twitter date to Python datetime date
import time
def convert_twitter_date_to_python_date(d):
    return time.strftime('%Y-%m-%d %H:%M:%S', time.strptime(d,'%a %b %d %H:%M:%S +0000 %Y'))
# Test
print(convert_twitter_date_to_python_date('Tue Mar 29 08:11:25 +0000 2011'))
