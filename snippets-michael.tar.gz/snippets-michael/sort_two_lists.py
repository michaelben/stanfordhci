# 13668393
# python sorting two lists
from operator import itemgetter
def sort_two_lists(list1, list2):
    ''' sort list1 with list2 pegged in order '''
    return [list(x) for x in zip(*sorted(zip(list1, list2), key=itemgetter(0)))]
# Test
print(sort_two_lists([1, 2, 5, 4, 4, 3, 6], [3, 2, 1, 2, 1, 7, 8]))
