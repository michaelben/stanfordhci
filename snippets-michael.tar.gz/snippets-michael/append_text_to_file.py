# 9297557
# Append a text to file in Python
import os.path

def append_text_to_file(txtfile):
    if not os.path.isfile(txtfile):
        with open(txtfile, 'w', encoding='utf-8') as file:
            file.write('Spam and eggs!')
    else: 
        with open(txtfile, 'a', encoding='utf-8') as file:
            file.write('Spam and eggs!')
# Test
append_text_to_file('text0415_2.txt')
