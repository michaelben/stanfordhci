# 2720396
# how to remove attribute of a etree Element?
from lxml import etree 
from lxml.builder import E
def remove_attribute_etree_element():
    otree = E.div()
    otree.set("id","123")
    otree.set("data","321")
    print(etree.tostring(otree))
    del otree.attrib["data"]
    print(etree.tostring(otree))
# Test
remove_attribute_etree_element()
