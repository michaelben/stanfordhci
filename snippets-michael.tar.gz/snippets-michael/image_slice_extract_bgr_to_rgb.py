# 15072736
# Extracting a region from an image using slicing in Python, OpenCV
import cv2
import numpy as np
import matplotlib.pyplot as plt

def image_slice_extract_bgr_to_rgb(imgfile):
    I = cv2.imread(imgfile)
    I2 = I[:,:,::-1]
    region = I2[248:280,245:288]
    cv2.imshow('image region', region)
# Test
image_slice_extract_bgr_to_rgb('logo.png.2')
