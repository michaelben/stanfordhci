# 1250688
# Decompressing a .bz2 file in Python
import bz2
def decompress_bz2_file(zipFile):
    return bz2.BZ2File(zipFile).read()
# Test
decompress_bz2_file('test.bz2')
