# 10252448
# Check whether a sentence is correct (simple grammar check in Python)
import language_check
import subprocess
import sys

def simple_grammar_check(text):
    try:
        subprocess.check_call(['java', '-version'], stderr=subprocess.DEVNULL)
    except:
        print("language_check depends on java. You need to install java for grammar check\n")
        sys.exit(-1)

    tool = language_check.LanguageTool('en-US')
    matches = tool.check(text)
    print(matches[0].fromy, matches[0].fromx)
    print(matches[0].ruleId, matches[0].replacements)
    print(matches[1].fromy, matches[1].fromx)
    print(matches[1].ruleId, matches[1].replacements)
    print(matches[1])
    print(language_check.correct(text, matches))
# Test
simple_grammar_check('A sentence with a error in the Hitchhiker’s Guide tot he Galaxy')
