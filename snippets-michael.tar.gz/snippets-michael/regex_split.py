# 14689044
# split a comma, space, or semicolon separated string using regex
import re
def regex_split(s):
    return re.findall(r'[^,;\s]+', s)
# Test
print(regex_split('a,,b,c,'))
