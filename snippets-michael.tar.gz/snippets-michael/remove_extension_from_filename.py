# 15849521
# Get rid of extenstions from file basename using python
import os.path
def remove_extension_from_filename(fname):
    return os.path.splitext(os.path.basename(fname))[0]
# Test
print(remove_extension_from_filename('home/robert/Documents/Workspace/datafile.xlsx'))
