# 704945
# check permissions of directories in python
import os
import stat
import sys

def get_dirs_with_permission(folder, mode):
    def mode_matches(mode, file):
        """Return True if 'file' matches 'mode'.

        'mode' should be an integer representing an octal mode (eg
        int("755", 8) -> 493).
        """
        # Extract the permissions bits from the file's (or
        # directory's) stat info.
        filemode = stat.S_IMODE(os.stat(file).st_mode)

        return filemode == mode

    # Convert mode to octal.
    mode = int(mode, 8)

    for dirpath, dirnames, filenames in os.walk(folder):
        dirs = [os.path.join(dirpath, x) for x in dirnames]
        for dirname in dirs:
            if mode_matches(mode, dirname):
                print(dirname)
# Test
get_dirs_with_permission('.', '755')
