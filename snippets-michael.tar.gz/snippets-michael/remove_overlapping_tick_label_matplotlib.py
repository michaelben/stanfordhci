# 9422587
# Overlapping y-axis tick label and x-axis tick label in matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import numpy as np
def remove_overlapping_tick_label_matplotlib():
    xx = np.arange(0,5, .5)
    yy = np.random.random( len(xx) )
    plt.plot(xx,yy)
    plt.gca().xaxis.set_major_locator(MaxNLocator(prune='lower'))
    plt.show()
# Test
remove_overlapping_tick_label_matplotlib()
