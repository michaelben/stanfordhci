# 13093727
# Replace unicode characters in string with something else

def unicode_replace(src, replaced, replacement):
    return src.replace(replaced, replacement)

print(unicode_replace(u'ABC•def', u"\u2022", 'X'))
