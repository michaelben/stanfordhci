# 9652832
# How to I load a tsv file into a Pandas DataFrame?
import pandas as pd
def load_csv_into_dataframe_pandas(csvfile):
    return pd.DataFrame.from_csv(csvfile, sep=',', header=1)
# Test
print(load_csv_into_dataframe_pandas('test0429.csv'))
