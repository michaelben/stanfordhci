# 1303021
# Shortest hash in python to name cache files
import base64
def shortest_hash(h):
    ''' 'h' is a string of hex digits'''
    bytes_str = "".join(chr(int(h[i:i+2], 16)) for i in range(0, len(h), 2))
    hashstr = base64.urlsafe_b64encode(bytes_str.encode()).decode().rstrip("=")
    return hashstr
# Test
print(shortest_hash('234abe'))
