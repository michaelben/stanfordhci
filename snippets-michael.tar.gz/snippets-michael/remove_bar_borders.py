# 15904042
# matplotlib bar graph black - remove bar borders
import matplotlib.pyplot as plt

def remove_bar_borders():
    plt.bar(edgecolor = 'none')
# Test
