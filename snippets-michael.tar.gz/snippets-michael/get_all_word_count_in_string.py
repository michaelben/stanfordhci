# 120071
# Find the count of a word in a string
from collections import Counter
def get_all_word_count_in_string(s):
    words = s.split()
    return Counter(words)
# Test
print(get_all_word_count_in_string("Hello I am going to I with hello am"))
