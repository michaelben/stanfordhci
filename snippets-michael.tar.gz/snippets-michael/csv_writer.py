# 3976711
# CSVWriter saving data to file
import csv
def csv_writer(csv_fname, rows):
    with open(csv_fname,'w') as myfile:
        wrtr = csv.writer(myfile, delimiter=',', quotechar='"')
        for row in rows:
            wrtr.writerow(row)
# Test
csv_writer('myfile.csv', [[1,2,3],[4,5,6],[7,8,9]])
