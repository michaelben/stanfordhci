# 873419
# Converting to safe unicode in python
def convert_unicode(s, from_encoding, to_encoding):
    return s.decode(from_encoding).encode(to_encoding)
# Test
print(convert_unicode(b'Fabulous home on one of Decatur\x92s most', 'cp1252', 'utf8'))
