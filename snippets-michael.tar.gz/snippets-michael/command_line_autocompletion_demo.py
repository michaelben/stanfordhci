# 209484
# python command-line autocompletion but NOT only at the beginning of a string
import readline

def command_line_autocompletion_demo():
    values = ['Paul Eden <paul@domain.com>', 
              'Eden Jones <ejones@domain.com>', 
              'Somebody Else <somebody@domain.com>']
    completions = {}

    def completer(text, state):
        try:
            matches = completions[text]
        except KeyError:
            matches = [value for value in values
                       if text.upper() in value.upper()]
            completions[text] = matches
        try:
            return matches[state]
        except IndexError:
            return None

    readline.set_completer(completer)
    readline.parse_and_bind('tab: menu-complete')

    while 1:
        a = input('> ')
        print('said:', a)
# Test
#command_line_autocompletion_demo()
