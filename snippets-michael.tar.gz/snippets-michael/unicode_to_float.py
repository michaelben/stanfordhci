# 1263796
# Convert unicode characters to floats
import unicodedata
def unicode_to_float(u):
    return unicodedata.numeric(u)
# Test
print(unicode_to_float(u'⅕'))
