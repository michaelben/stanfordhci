# 558216
# Function to determine if two numbers are nearly equal when rounded to n significant decimal digits
import numpy as np
import sys

def nearly_equal(actual, desired, significant):
    try:
        np.testing.assert_approx_equal(actual,desired,significant=significant,err_msg='',verbose=True)
    except AssertionError as e:
        print("(%g, %g) are equal up to %d digits" % (actual, desired, significant))
    else:
        print("(%g, %g) are not equal up to %d digits" % (actual, desired, significant))
# Test
nearly_equal( 1e4, 1e4 + 1, 5)
nearly_equal( 0.0, 1e-15, 5 )
