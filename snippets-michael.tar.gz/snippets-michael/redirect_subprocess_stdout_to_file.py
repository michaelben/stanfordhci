# 3979888
# Capture output from subprocess.call to a file
import subprocess
def redirect_subprocess_stdout_to_file(cmd, outname):
    with open(outname,'w') as f:
        subprocess.call(cmd, shell=True, stdout=f)
# Test
redirect_subprocess_stdout_to_file(['dir', '.'], 'log0419.txt')
