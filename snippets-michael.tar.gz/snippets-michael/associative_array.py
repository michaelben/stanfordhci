# 9495950
# Implement associative array (not dictionary) in Python
from collections import OrderedDict
def associative_array(arr):
    return OrderedDict(arr)
# Test
print(associative_array({"Forename":"Paul","Surname":"Dinh"}))
