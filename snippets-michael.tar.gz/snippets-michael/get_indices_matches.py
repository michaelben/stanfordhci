# 4937634
# In Python, how to compare two lists and get all indices of matches?
def get_indices_matches(list1, list2):
    return [([int(item1 == item2) for item2 in list2], [n for n, item2 in enumerate(list2) if item1 == item2]) for item1 in list1]
# Test
print(get_indices_matches(['AS144','401M','31TP01'], ['HDE342','114','M9553','AS144','AS144','401M']))
