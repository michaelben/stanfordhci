# 10525921
# numpy.array boolean to binary
import numpy as np
def boolean_to_int_numpy(array):
    return array.astype(int)
# Test
print(boolean_to_int_numpy(np.array([True, False, False, False])))
