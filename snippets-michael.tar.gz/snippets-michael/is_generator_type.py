# 6416538
# Check if an object is a generator object
import types
def is_generator_type(g):
    return isinstance(g, types.GeneratorType)
# Test
print(is_generator_type((i for i in range(10))))
