# 209840
# map two lists into a dictionary

def map_two_lists(l1, l2):
    return dict(zip(l1, l2))

print(map_two_lists(['a', 'b', 'c'], [1, 2, 3]))
