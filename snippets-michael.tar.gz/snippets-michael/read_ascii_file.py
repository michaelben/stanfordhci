# 7497328
# Reading ASCII file in Python (numpy-array?)
import numpy as np
def read_ascii_file():
    x = np.genfromtxt("example.txt", dtype=None)
    print(x[0])
# Test
