# 9993939
# Django: Display values of the selected multiple choice field in a template
def selected_genders_labels(self):
    return [label for value, label in self.fields['genders'].choices if value in self['genders'].value()]
# Test
