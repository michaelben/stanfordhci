# 11332465
# Return value from Python as JSON
import json
def return_value_as_json(obj):
    return json.dumps(obj)
# Test
print(return_value_as_json({'file_id': 1, 'filename': 'filename', 'links_to' : 'http://example.com/filename'}))
