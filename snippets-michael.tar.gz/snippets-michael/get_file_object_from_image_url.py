# 3445568
# Python/Django download Image from URL, modify, and save to ImageField
import requests
from PIL import Image, ImageFile    
from django.core.files import File
from io import BytesIO

def get_file_object_from_image_url(imageurl, filename):
    img_temp = BytesIO(requests.get(imageurl).content)
    inImage = Image.open(img_temp)
    # convert to RGB to avoid error with png and tiffs
    if inImage.mode != "RGB":
        inImage = inImage.convert("RGB")

    file_object = File(img_temp, filename)

    return file_object, inImage, img_temp
# Test
print(get_file_object_from_image_url('http://www.wmpic.me/wp-content/uploads/2014/06/20140611165820713.jpeg', 'cat.jpeg'))
