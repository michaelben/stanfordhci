# 11206884
# How to write Python sort key functions for descending values
from operator import attrgetter
from datetime import datetime

def multiple_sort_demo():
    class A():
        def __init__(self, date, s):
            self.date = date
            self.s = s
        def repr(self):
            return self.date, self.s

    data = [A(datetime(2001,1,1), '1'),
            A(datetime(2002,1,1), '4'),
            A(datetime(2002,1,1), '3'),
            A(datetime(2002,1,1), '2'),
            A(datetime(2005,1,1), '5')]
    keys = [ (attrgetter('date'), True), (attrgetter('s'), False) ]

    def multiple_sort(data, keys):
        for key, rev in reversed(keys):
            data = sorted(data, key=key, reverse=rev)
        return data

    print([o.repr() for o in multiple_sort(data, keys)])
# Test
multiple_sort_demo()
