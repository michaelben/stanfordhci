# 338450
# TimedRotatingFileHandler Changing File Name
import logging
import logging.handlers
def getLogger(log_fname):
    LOGGING_MSG_FORMAT  = '%(name)-14s > [%(levelname)s] [%(asctime)s] : %(message)s'
    LOGGING_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'

    logging.basicConfig(
                level=logging.DEBUG,
                format=LOGGING_MSG_FORMAT,
                datefmt=LOGGING_DATE_FORMAT
                )
    root_logger = logging.getLogger('')
    handler = logging.handlers.TimedRotatingFileHandler(log_fname,'midnight',1)
    handler.suffix = "%Y%m%d" # or anything else that strftime will allow
    handler.extMatch = re.compile(r"^\d{8}$")
    root_logger.addHandler(handler)
    return root_logger
# no test
