# 7583652
# Python Module with a dash, or hyphen (-) in its name
import sys
def import_module_with_dash_hyphen():
    try:
        foobar = __import__("foo-bar")
    except:
        sys.exit(-1)
# Test
import_module_with_dash_hyphen()
