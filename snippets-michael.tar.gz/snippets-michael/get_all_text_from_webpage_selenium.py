# 7947579
# Getting all visible text from a webpage using Selenium
import contextlib
import selenium.webdriver as webdriver
import lxml.html as LH
import lxml.html.clean as clean

def get_all_text_from_webpage_selenium(url):
    result = []
    ignore_tags=('script','noscript','style')
    with contextlib.closing(webdriver.Firefox()) as browser:
        browser.get(url)
        content=browser.page_source
        cleaner=clean.Cleaner()
        content=cleaner.clean_html(content)    
        doc=LH.fromstring(content)
        for elt in doc.iterdescendants():
            if elt.tag in ignore_tags: continue
            text=elt.text or ''
            tail=elt.tail or ''
            words=' '.join((text,tail)).strip()
            if words:
                result.append(words)
    return result
# Test
print(get_all_text_from_webpage_selenium('http://www.wikipedia.org'))
