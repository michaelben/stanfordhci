# 6558535
# Python: Find the date for the first Monday after a given a date
import datetime
def next_weekday(d, weekday):
    '''
    d: the given date
    weekday: 0 = Monday, 1 = Tuesday, 2 = Wednesday
    '''
    days_ahead = weekday - d.weekday()
    if days_ahead <= 0: # Target day already happened this week
        days_ahead += 7
    return d + datetime.timedelta(days_ahead)

# Test
print(next_weekday(datetime.date(2011, 7, 2), 0))
