# 12402015
# Print the key of the max value in a dictionary the pythonic way
def get_dict_max_key(d):
    return max(d, key=d.get)
# Test
print(get_dict_max_key({'a':2,'b':3,'c':1}))
