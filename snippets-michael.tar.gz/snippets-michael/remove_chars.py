# 3588361
# python: Replace all occurrences of certain characters
def remove_chars(a, badchars=['a','b','c','d']):
    for row in a:
        for letter in badchars:
            row[8] = row[8].replace(letter,'')
    return a
# Test
print(remove_chars([[1,2,3,4,5,6,7,8,'adsfa'], [1,2,3,4,5,6,7,8,'agdkfhg']]))
