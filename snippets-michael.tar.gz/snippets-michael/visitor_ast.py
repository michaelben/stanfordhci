# 2525677
# Visitor Pattern for Abstract Syntax Tree in Python
import ast

def visitor_ast():
    class MyVisitor(ast.NodeVisitor):
        def visit_BinaryOp(self, node):
            self.visit(node.left)
            print(node.op)
            self.visit(node.right)
        def visit_Num(self, node):
            print(node.n)
# Test
