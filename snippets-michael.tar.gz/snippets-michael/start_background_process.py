# 1196074
# Starting a background process

import subprocess

def start_background_process(cmd):
    subprocess.Popen(cmd)

start_background_process(["rm","-r","some.file"])
