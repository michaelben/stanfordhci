# 5665114
# Python - value in list of dictionaries
def dict_membership(result, mydictlist):
    for r in result:
        for d in mydictlist:
            if d['value'] == r:
                print(r + " ok")
# Test
dict_membership(['n1', 'n4'], [{'t':'fv', 'value':'n1'}, {'t':'tv', 'value':'n2'}])
