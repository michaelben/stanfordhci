# 8191721
# SMTPHandler in Python's logging module sending emails one at a time. How can I stop this?
import logging, logging.handlers

def logging_buffering_smtphandler():
    log = logging.getLogger("mylogger")
    log.setLevel(logging.DEBUG)
    h2 = logging.handlers.BufferingSMTPHandler(mailhost='mailserver',
                                        fromaddr='noreply@example.com',
                                        toaddrs=['me@example.com'],
                                        subject='The log',
                                        credentials=('user','pwd'),
                                        secure=None)
    h2.setLevel(logging.INFO)
    h2.setFormatter(f)
    log.addHandler(h2)

    log.info("Did something")
    log.info("Did something else")
    log.info("This would send a third email. :-(")

    h2.flush()
# Test
