# 120071
# Find the count of a word in a string
def get_word_count_in_string(s, word):
    return s.count(word)
# Test
print(get_word_count_in_string("Hello I am going to I with hello am", 'am'))
