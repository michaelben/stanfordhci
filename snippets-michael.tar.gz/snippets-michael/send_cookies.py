# 7164679
# Send cookies in a post request with the Python Requests library

import requests

def send_cookies(url, cookie):
    return requests.post(url, cookies=cookie)

url = 'http://wikipedia.org'
cookie = {'enwiki_session': '17ab96bd8ffbe8ca58a78657a918558'}
print(requests.post(url, cookie))
