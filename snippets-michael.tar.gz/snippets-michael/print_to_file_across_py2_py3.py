# 9236198
# python3 operator >> to print to file
from __future__ import print_function
import os

def print_to_file_across_py2_py3(s, file):
    print(s, end='', file=file)
# Test
print_to_file_across_py2_py3('test data', open(os.devnull, 'a'))
