# 2403372
# Get values (objects) from a dictionary of objects in which one of the object's field matches a value (or condition)

def filter_dict(myDict, value):
	return dict((k,v) for k, v in myDict.items() if v.field2 >= value)

# Test
class DictItem:
   def __init__(self, field1, field2):
      self.field1 = str(field1)
      self.field2 = int(field2)

print(filter_dict({"sampleKey1" : DictItem("test1", 1), 
    "sampleKey2" : DictItem("test2", 2),
    "sampleKey3" : DictItem("test3", 3)}, 2))
