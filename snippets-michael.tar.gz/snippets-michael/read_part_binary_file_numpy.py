# 14245094
# Read part of binary file with numpy
import numpy as np
import os
def read_part_binary_file_numpy():
    data = np.arange(100, dtype=np.int)
    data.tofile("numpy.temp")  # save the data

    f = open("numpy.temp", "rb")  # reopen the file
    f.seek(256, os.SEEK_SET)  # seek

    x = np.fromfile(f, dtype=np.int)  # read the data into numpy
    print(x)
# Test
read_part_binary_file_numpy()
