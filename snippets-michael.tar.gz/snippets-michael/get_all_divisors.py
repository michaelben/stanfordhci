# 12421969
# Finding all divisors of a number optimization
def get_all_divisors(n):
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 91, 97]
    def factorize(n, primes):
        factors = []
        for p in primes:
            if p*p > n: break
            i = 0
            while n % p == 0:
                n //= p
                i+=1
            if i > 0:
                factors.append((p, i));
        if n > 1: factors.append((n, 1))

        return factors

    factors = factorize(n, primes)
    div = [1]
    for (p, r) in factors:
        div = [d * p**e for d in div for e in range(r + 1)]
    return div
# Test
print(get_all_divisors(888))
