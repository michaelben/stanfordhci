# 16082954
# Python: Sort a list of dictionaries by several values
def sort_list_dicts_multiple_values(a):
    return sorted(a, key = lambda user: (user['name'], user['age']))
# Test
print(sort_list_dicts_multiple_values([{'name':'john','age':45},
         {'name':'andi','age':23},
         {'name':'john','age':22},
         {'name':'paul','age':35},
         {'name':'john','age':21}]))
