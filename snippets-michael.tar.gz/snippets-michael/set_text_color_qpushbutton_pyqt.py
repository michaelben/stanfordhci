# 6188431
# Set the colour of text in a QPushButton in PyQt4 using Python
def set_text_color_qpushbutton_pyqt():
    testbutton = qt.QPushButton("Test")
    testbutton.setStyleSheet('QPushButton {color: blue}')
# Test
