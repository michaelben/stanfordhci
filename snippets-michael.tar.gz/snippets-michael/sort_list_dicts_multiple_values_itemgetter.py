# 16082954
# Python: Sort a list of dictionaries by several values
from operator import itemgetter
def sort_list_dicts_multiple_values_itemgetter(a):
    return sorted(a, key=itemgetter('name', 'age'))
# Test
print(sort_list_dicts_multiple_values_itemgetter([{'name':'john','age':45},
         {'name':'andi','age':23},
         {'name':'john','age':22},
         {'name':'paul','age':35},
         {'name':'john','age':21}]))
