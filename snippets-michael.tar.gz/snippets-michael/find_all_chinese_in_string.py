# 2718196
# Find all Chinese text in a string using Python and Regex
import re
def find_all_chinese_in_string(s):
    for n in re.findall('[\u4e00-\u9fff]+',s):
        print(n)
# Test
find_all_chinese_in_string('I am from 美国.We should be friends. 朋友.')
