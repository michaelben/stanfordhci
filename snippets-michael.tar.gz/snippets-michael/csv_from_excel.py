# 20105118
# Convert XLSX to CSV correctly using python
import xlrd
import csv

def csv_from_excel(excelfile, csvfile):
    wb = xlrd.open_workbook(excelfile)
    sh = wb.sheet_by_name('Sheet1')
    your_csv_file = open(csvfile, 'w')
    wr = csv.writer(your_csv_file, quoting=csv.QUOTE_ALL)

    for rownum in range(sh.nrows):
        wr.writerow([int(i) for i in sh.row_values(rownum)])

    your_csv_file.close()
# Test
csv_from_excel('test0409.xls', 'test0409.csv')
