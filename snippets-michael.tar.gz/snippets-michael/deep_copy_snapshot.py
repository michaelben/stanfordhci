# 2844837
# Avoid RuntimeError: dictionary changed size during iteration error
import copy
def deep_copy_snapshot(d):
    return copy.deepcopy(dict(d))
# Test
print(deep_copy_snapshot({1:1,2:2,3:3}))
