# 927552
# Parsing HTTP User-Agent string

import httpagentparser

def http_user_agent_parser(ua):
    return httpagentparser.detect(ua)

print(http_user_agent_parser("Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.9 (KHTML, like Gecko) Chrome/5.0.307.11 Safari/532.9"))
