# 485789
# TypeError: can't multiply sequence by non-int of type 'float' 3.3
def multiple_string_by_float(s, f):
    return float(s) * f
# Test
print(multiple_string_by_float('124', 0.5))
